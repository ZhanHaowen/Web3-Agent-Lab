# Web3 Agent 执行轨迹

运行编号：c8706d1b-eb80-4467-a37d-77725da16c4c

本文件由原始事件生成，用于查看执行关系。列表的记录顺序不代表因果关系；只有显式调用ID、交易哈希与callTracer父子关系形成连线。内部EVM调用是链执行证据，不是模型思维过程。

完整结构见同目录 execution-trace.json；模型原始完整响应body与工具原始记录通过 source_events.payload_ref 指向原始 blobs 文件。本文件不截断已展开实体。

## 任务与来源

```json
{
  "task": {
    "node_id": "task:c8706d1b-eb80-4467-a37d-77725da16c4c",
    "id": "transfer",
    "input": "从 agent 向 recipient 转账10 TokenA，确认链上执行结果。调用transfer_token时amount填人类可读代币数量字符串\"10\"，不要乘代币精度；钱包适配器负责转换一次。",
    "mode": "scripted",
    "experiment_mode": "continuous",
    "amount_validation": "fixed_task",
    "data_origin": "scripted",
    "allowed_tools": [
      "get_balance",
      "get_state",
      "transfer_token"
    ],
    "source_events": [
      {
        "seq": 4,
        "event_id": "939cd182-7865-473e-bffa-33a295b76103",
        "type": "agent.start",
        "timestamp": "2026-11-16T06:22:38.171Z",
        "monotonic_ms": 69.83909999999923,
        "payload_ref": {
          "sha256": "c609799c235047d73d9e98f1bc13970d43adad42fed34da80422c720dcb60dfe",
          "path": "blobs/c609799c235047d73d9e98f1bc13970d43adad42fed34da80422c720dcb60dfe.json",
          "bytes": 2953,
          "media_type": "application/json"
        }
      }
    ],
    "task_parameters": {
      "amount": "10"
    },
    "parameter_source": "structured",
    "continuation_of": null
  },
  "provenance": {
    "kind": "derived",
    "source": "original_events",
    "builder_version": "1.2",
    "manifest_present": true,
    "recording_status": "complete",
    "sealed_at": "2026-11-16T06:22:38.887Z",
    "event_count": 22,
    "events_sha256": "774f04d6fd2537c55ae5de082f23ae9c78872235703107aeb58de2cc49fcb14f",
    "integrity": "raw_manifest_verified_before_derivation",
    "source_manifest_sha256": "a260de56efeddb55a098c07a7803f79aee9c77143ccb56661f75b031f925d9d6"
  },
  "summary": {
    "model_call_count": 0,
    "model_proposal_count": 0,
    "tool_call_count": 1,
    "tool_record_count": 1,
    "contract_call_count": 1,
    "explicit_contract_call_count": 1,
    "transaction_count": 1,
    "call_frame_count": 1,
    "edge_count": 5,
    "transaction_status_counts": {
      "success": 1
    },
    "model_used": false,
    "internal_trace_meaning": "EVM execution evidence; not model reasoning",
    "completeness": "recorded_events_only"
  }
}
```

## 步骤关系表

| 来源节点 | 关系 | 目标节点 | 原始事件序号 |
| --- | --- | --- | --- |
| task:c8706d1b-eb80-4467-a37d-77725da16c4c | scripted\_task\_step | tool:scripted\_5fb0a694-ee57-4597-8cd0-4f5431245b00 | 6 |
| tool:scripted\_5fb0a694-ee57-4597-8cd0-4f5431245b00 | invokes\_contract | contract:6e6eb542-8c30-4b20-a567-2354f3797ab0 | 9, 16 |
| transaction:0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a | evm\_trace\_root | evm:a7f404e1-e07c-4702-9aef-8390f4744110%2F0 | 15 |
| contract:6e6eb542-8c30-4b20-a567-2354f3797ab0 | submits\_transaction | transaction:0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a | 12, 13, 21 |
| tool:scripted\_5fb0a694-ee57-4597-8cd0-4f5431245b00 | submits\_transaction | transaction:0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a | 12, 13, 21 |

## 模型接口调用与提议（提议不等于工具执行）

没有记录到此类实体；不能据此补造调用。

## 工具执行（输入、原始结果、可见结果）

### tool:scripted\_5fb0a694-ee57-4597-8cd0-4f5431245b00

```json
{
  "id": "tool:scripted_5fb0a694-ee57-4597-8cd0-4f5431245b00",
  "source_events": [
    {
      "seq": 7,
      "event_id": "d14ccae8-7959-4fe1-9b27-537ca5889f9f",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:38.181Z",
      "monotonic_ms": 79.54550000000017,
      "payload_ref": {
        "sha256": "55e97ad195b11ee261f1edb669325d06e9d957a9a30202ddc90925a1ec9c7afc",
        "path": "blobs/55e97ad195b11ee261f1edb669325d06e9d957a9a30202ddc90925a1ec9c7afc.json",
        "bytes": 193,
        "media_type": "application/json"
      }
    },
    {
      "seq": 8,
      "event_id": "3cbc2c66-063d-4f4a-a4b9-9331c6907297",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:38.182Z",
      "monotonic_ms": 80.95750000000044,
      "payload_ref": {
        "sha256": "c698f9bab51c532f6c1cbb2df9f6f1d6d7e17dd5cf208020b9abd8e9db9af9d5",
        "path": "blobs/c698f9bab51c532f6c1cbb2df9f6f1d6d7e17dd5cf208020b9abd8e9db9af9d5.json",
        "bytes": 114,
        "media_type": "application/json"
      }
    },
    {
      "seq": 17,
      "event_id": "9a7dec3e-52df-4211-b583-7af7bf461f20",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:38.572Z",
      "monotonic_ms": 471.023799999999,
      "payload_ref": {
        "sha256": "ef38ad04dac8f7b24a86b6aa0d184f611224247d09b16a144cb5dcc31a77defa",
        "path": "blobs/ef38ad04dac8f7b24a86b6aa0d184f611224247d09b16a144cb5dcc31a77defa.json",
        "bytes": 7015,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_5fb0a694-ee57-4597-8cd0-4f5431245b00",
  "modelCallId": null,
  "name": "transfer_token",
  "raw_arguments": "{\"token\":\"A\",\"recipient\":\"recipient\",\"amount\":\"10\"}",
  "input": {
    "token": "A",
    "recipient": "recipient",
    "amount": "10"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "transfer_token",
    "args": {
      "token": "A",
      "recipient": "recipient",
      "amount": "10"
    },
    "contractCallId": "6e6eb542-8c30-4b20-a567-2354f3797ab0",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      }
    ],
    "operation": "task:transfer_token",
    "hash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "txHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0xa9059cbb00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c10000000000000000000000000000000000000000000000000000000000989680",
    "value": "0",
    "nonce": 7,
    "gas": "51705",
    "type": "eip1559",
    "maxFeePerGas": "1548222598",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1400005678",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "51705",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c1"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
          "blockNumber": "8",
          "blockTimestamp": "1794810158",
          "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000440000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000080008000000000400000000000000000000800000000000000000000000000000000000000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
      "transactionIndex": 0,
      "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
      "blockNumber": "8",
      "gasUsed": "51705",
      "effectiveGasPrice": "1400005678",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810158
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "transfer",
      "args": [
        "0x79F39560Cfc10098e433448209Eca3b3cb76f0c1",
        "10000000"
      ]
    }
  },
  "visible_result": {
    "tool": "transfer_token",
    "args": {
      "token": "A",
      "recipient": "recipient",
      "amount": "10"
    },
    "contractCallId": "6e6eb542-8c30-4b20-a567-2354f3797ab0",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      }
    ],
    "operation": "task:transfer_token",
    "hash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "txHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0xa9059cbb00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c10000000000000000000000000000000000000000000000000000000000989680",
    "value": "0",
    "nonce": 7,
    "gas": "51705",
    "type": "eip1559",
    "maxFeePerGas": "1548222598",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1400005678",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "51705",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c1"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
          "blockNumber": "8",
          "blockTimestamp": "1794810158",
          "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000440000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000080008000000000400000000000000000000800000000000000000000000000000000000000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
      "transactionIndex": 0,
      "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
      "blockNumber": "8",
      "gasUsed": "51705",
      "effectiveGasPrice": "1400005678",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810158
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "transfer",
      "args": [
        "0x79F39560Cfc10098e433448209Eca3b3cb76f0c1",
        "10000000"
      ]
    }
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 7,
    "end_seq": 17,
    "start_time": "2026-11-16T06:22:38.181Z",
    "end_time": "2026-11-16T06:22:38.572Z",
    "duration_ms": 391.47829999999885
  }
}
```


## 合约调用（读取或写交易）

### contract:6e6eb542-8c30-4b20-a567-2354f3797ab0

```json
{
  "id": "contract:6e6eb542-8c30-4b20-a567-2354f3797ab0",
  "source_events": [
    {
      "seq": 9,
      "event_id": "3c5597c8-e24a-4a8e-a6b3-841810481a05",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:38.206Z",
      "monotonic_ms": 104.53110000000015,
      "payload_ref": {
        "sha256": "75ac4a10670d72ca64ac3ee3d1b277064356fabc4fd77eecc30116089f5dc83e",
        "path": "blobs/75ac4a10670d72ca64ac3ee3d1b277064356fabc4fd77eecc30116089f5dc83e.json",
        "bytes": 934,
        "media_type": "application/json"
      }
    },
    {
      "seq": 16,
      "event_id": "a2d1f486-7b58-4b10-b9e3-040105a9469a",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:38.571Z",
      "monotonic_ms": 469.8256999999994,
      "payload_ref": {
        "sha256": "a06ec73fe2211333e1d3093c83d6bc9ab997bd8078e2ec8ab6da7e6172ed1985",
        "path": "blobs/a06ec73fe2211333e1d3093c83d6bc9ab997bd8078e2ec8ab6da7e6172ed1985.json",
        "bytes": 3687,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "6e6eb542-8c30-4b20-a567-2354f3797ab0",
  "toolCallId": "scripted_5fb0a694-ee57-4597-8cd0-4f5431245b00",
  "kind": "transaction",
  "tool": "transfer_token",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "label": "transfer"
  },
  "function": {
    "name": "transfer",
    "signature": "transfer(address,uint256)",
    "selector": "0xa9059cbb",
    "args": [
      "0x79F39560Cfc10098e433448209Eca3b3cb76f0c1",
      "10000000"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0xa9059cbb00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c10000000000000000000000000000000000000000000000000000000000989680",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "10",
      "baseUnits": "10000000"
    }
  ],
  "result": {
    "tool": "transfer_token",
    "args": {
      "token": "A",
      "recipient": "recipient",
      "amount": "10"
    },
    "contractCallId": "6e6eb542-8c30-4b20-a567-2354f3797ab0",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      }
    ],
    "operation": "task:transfer_token",
    "hash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "txHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0xa9059cbb00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c10000000000000000000000000000000000000000000000000000000000989680",
    "value": "0",
    "nonce": 7,
    "gas": "51705",
    "type": "eip1559",
    "maxFeePerGas": "1548222598",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1400005678",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "51705",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c1"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
          "blockNumber": "8",
          "blockTimestamp": "1794810158",
          "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000440000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000080008000000000400000000000000000000800000000000000000000000000000000000000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
      "transactionIndex": 0,
      "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
      "blockNumber": "8",
      "gasUsed": "51705",
      "effectiveGasPrice": "1400005678",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810158
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "transfer",
      "args": [
        "0x79F39560Cfc10098e433448209Eca3b3cb76f0c1",
        "10000000"
      ]
    }
  },
  "txHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
  "submitted": true,
  "start_end": {
    "start_seq": 9,
    "end_seq": 16,
    "start_time": "2026-11-16T06:22:38.206Z",
    "end_time": "2026-11-16T06:22:38.571Z",
    "duration_ms": 365.29459999999926
  }
}
```


## 交易与确认状态

### transaction:0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a

```json
{
  "id": "transaction:0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
  "hash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
  "contractCallId": "6e6eb542-8c30-4b20-a567-2354f3797ab0",
  "toolCallId": "scripted_5fb0a694-ee57-4597-8cd0-4f5431245b00",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0xa9059cbb00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c10000000000000000000000000000000000000000000000000000000000989680",
    "value": "0",
    "nonce": 7,
    "gas": "51705",
    "maxFeePerGas": "1548222598",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1400005678"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "51705",
    "logs": [
      {
        "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
        "topics": [
          "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c1"
        ],
        "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
        "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
        "blockNumber": "8",
        "blockTimestamp": "1794810158",
        "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      }
    ],
    "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000440000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000080008000000000400000000000000000000800000000000000000000000000000000000000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000",
    "transactionHash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
    "transactionIndex": 0,
    "blockHash": "0xc57f89d034f5c9da8f58a82ce2f6815e040fbcbb0d2d32a983bbcd6b8bb2dcba",
    "blockNumber": "8",
    "gasUsed": "51705",
    "effectiveGasPrice": "1400005678",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "contractAddress": null,
    "blockTimestamp": 1794810158
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 10,
      "event_id": "d3c6cc28-dc94-462b-9593-771f0905f0ae",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:38.386Z",
      "monotonic_ms": 284.3248000000003,
      "payload_ref": {
        "sha256": "7db9cbea884449564aa3c63043d4644519e2ea23778c1c84f2d03d5bfe4a1a20",
        "path": "blobs/7db9cbea884449564aa3c63043d4644519e2ea23778c1c84f2d03d5bfe4a1a20.json",
        "bytes": 1158,
        "media_type": "application/json"
      }
    },
    {
      "seq": 12,
      "event_id": "1701185c-8c46-481b-a734-8b1bb0c6ccb3",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:38.436Z",
      "monotonic_ms": 334.3904999999995,
      "payload_ref": {
        "sha256": "323b0452b53b712ab79beed85b9c48b1167ad417c72be50c35bfd9284f702ea2",
        "path": "blobs/323b0452b53b712ab79beed85b9c48b1167ad417c72be50c35bfd9284f702ea2.json",
        "bytes": 1158,
        "media_type": "application/json"
      }
    },
    {
      "seq": 13,
      "event_id": "5fa4bf1b-3ed6-483d-a580-84b50fffc5cf",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:38.545Z",
      "monotonic_ms": 443.79739999999947,
      "payload_ref": {
        "sha256": "7a4f10eee4d3a1ad72e43ee72467ed7135d2b50179a9e36086d1f7376852ed17",
        "path": "blobs/7a4f10eee4d3a1ad72e43ee72467ed7135d2b50179a9e36086d1f7376852ed17.json",
        "bytes": 3304,
        "media_type": "application/json"
      }
    },
    {
      "seq": 15,
      "event_id": "a7f404e1-e07c-4702-9aef-8390f4744110",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:38.569Z",
      "monotonic_ms": 467.2561000000005,
      "payload_ref": {
        "sha256": "bd30f580dcfbde58fd6c09755da35a8fc21b52dade17a81895b747e6cb7ffe30",
        "path": "blobs/bd30f580dcfbde58fd6c09755da35a8fc21b52dade17a81895b747e6cb7ffe30.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    },
    {
      "seq": 21,
      "event_id": "975ce018-9d9e-403f-8bc5-947d16c95946",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:38.871Z",
      "monotonic_ms": 770.1293000000005,
      "payload_ref": {
        "sha256": "21849243561421af267880a0700dbb2c77f98b939cbc409277868bd8208c012f",
        "path": "blobs/21849243561421af267880a0700dbb2c77f98b939cbc409277868bd8208c012f.json",
        "bytes": 12533,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "10",
      "baseUnits": "10000000"
    }
  ],
  "decoded": {
    "functionName": "transfer",
    "args": [
      "0x79F39560Cfc10098e433448209Eca3b3cb76f0c1",
      "10000000"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 10,
    "end_seq": 21,
    "start_time": "2026-11-16T06:22:38.386Z",
    "end_time": "2026-11-16T06:22:38.871Z",
    "duration_ms": 485.8045000000002
  }
}
```


## 内部EVM调用帧（callTracer父子树）

### evm:a7f404e1-e07c-4702-9aef-8390f4744110%2F0

```json
{
  "id": "evm:a7f404e1-e07c-4702-9aef-8390f4744110%2F0",
  "callId": "evm:a7f404e1-e07c-4702-9aef-8390f4744110%2F0",
  "parentId": null,
  "transaction_id": "transaction:0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
  "hash": "0x1758390149d627c74ea58006cf5c2e6181b8705d8aef80461fc637d85363c03a",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0xa9059cbb00000000000000000000000079f39560cfc10098e433448209eca3b3cb76f0c10000000000000000000000000000000000000000000000000000000000989680",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x75a9",
  "gasUsed": "0xc9f9",
  "function": {
    "name": "transfer",
    "signature": "transfer(address,uint256)",
    "selector": "0xa9059cbb",
    "args": [
      "0x79F39560Cfc10098e433448209Eca3b3cb76f0c1",
      "10000000"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "a7f404e1-e07c-4702-9aef-8390f4744110",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:38.569Z",
      "monotonic_ms": 467.2561000000005,
      "payload_ref": {
        "sha256": "bd30f580dcfbde58fd6c09755da35a8fc21b52dade17a81895b747e6cb7ffe30",
        "path": "blobs/bd30f580dcfbde58fd6c09755da35a8fc21b52dade17a81895b747e6cb7ffe30.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:38.569Z",
    "end_time": "2026-11-16T06:22:38.569Z",
    "duration_ms": 0
  }
}
```


## 缺失与注意事项

未发现构建阶段结构警告。原始文件哈希核验由导出调用方负责；轨迹本身不判定任务成功。
