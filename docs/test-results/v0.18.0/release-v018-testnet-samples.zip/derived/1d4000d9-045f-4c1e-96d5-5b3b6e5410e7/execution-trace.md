# Web3 Agent 执行轨迹

运行编号：1d4000d9-045f-4c1e-96d5-5b3b6e5410e7

本文件由原始事件生成，用于查看执行关系。列表的记录顺序不代表因果关系；只有显式调用ID、交易哈希与callTracer父子关系形成连线。内部EVM调用是链执行证据，不是模型思维过程。

完整结构见同目录 execution-trace.json；模型原始完整响应body与工具原始记录通过 source_events.payload_ref 指向原始 blobs 文件。本文件不截断已展开实体。

## 任务与来源

```json
{
  "task": {
    "node_id": "task:1d4000d9-045f-4c1e-96d5-5b3b6e5410e7",
    "id": "approve",
    "input": "将agent的TokenA对实验amm的allowance设置为恰好22 TokenA。正确调用参数为{\"token\":\"A\",\"spender\":\"amm\",\"amount\":\"22\"}，不要乘代币精度。approve是覆盖设置而非增加；已有授权恰好22时可不提交交易。查看状态时优先读取formatted.allowances.ammA中的代币数量。",
    "mode": "scripted",
    "experiment_mode": "continuous",
    "amount_validation": "fixed_task",
    "data_origin": "scripted",
    "allowed_tools": [
      "get_balance",
      "get_state",
      "approve_token"
    ],
    "source_events": [
      {
        "seq": 4,
        "event_id": "385fa969-99ef-4d0d-8ccd-d98977fd233f",
        "type": "agent.start",
        "timestamp": "2026-11-16T06:22:43.089Z",
        "monotonic_ms": 71.17720000000008,
        "payload_ref": {
          "sha256": "2a7fff95e2bd8db0fd0ad659911d1bdca299e3160f19c21b1fe883c7cb4b3898",
          "path": "blobs/2a7fff95e2bd8db0fd0ad659911d1bdca299e3160f19c21b1fe883c7cb4b3898.json",
          "bytes": 3148,
          "media_type": "application/json"
        }
      }
    ],
    "task_parameters": {
      "amount": "22"
    },
    "parameter_source": "structured",
    "continuation_of": null
  },
  "provenance": {
    "kind": "derived",
    "source": "original_events",
    "builder_version": "1.2",
    "manifest_present": true,
    "recording_status": "complete",
    "sealed_at": "2026-11-16T06:22:47.737Z",
    "event_count": 26,
    "events_sha256": "7d0b4d4c2b87b59b0fbcb9a2ebecbb56329b4d2b0d1235423d2e86500acf7ac9",
    "integrity": "raw_manifest_verified_before_derivation",
    "source_manifest_sha256": "afe8a170c303802708d8a06ee2a68ae003eeeae2487afd60cf409775a6a8c9a7"
  },
  "summary": {
    "model_call_count": 0,
    "model_proposal_count": 0,
    "tool_call_count": 1,
    "tool_record_count": 1,
    "contract_call_count": 1,
    "explicit_contract_call_count": 1,
    "transaction_count": 1,
    "call_frame_count": 1,
    "edge_count": 5,
    "transaction_status_counts": {
      "success": 1
    },
    "model_used": false,
    "internal_trace_meaning": "EVM execution evidence; not model reasoning",
    "completeness": "recorded_events_only"
  }
}
```

## 步骤关系表

| 来源节点 | 关系 | 目标节点 | 原始事件序号 |
| --- | --- | --- | --- |
| task:1d4000d9-045f-4c1e-96d5-5b3b6e5410e7 | scripted\_task\_step | tool:scripted\_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d | 6 |
| tool:scripted\_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d | invokes\_contract | contract:08dd028d-16c3-44a1-ae40-a84087366fae | 11, 20 |
| transaction:0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2 | evm\_trace\_root | evm:c4642e85-e7b7-49e7-ae9a-ac9da8ce8c88%2F0 | 19 |
| contract:08dd028d-16c3-44a1-ae40-a84087366fae | submits\_transaction | transaction:0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2 | 16, 17, 25 |
| tool:scripted\_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d | submits\_transaction | transaction:0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2 | 16, 17, 25 |

## 模型接口调用与提议（提议不等于工具执行）

没有记录到此类实体；不能据此补造调用。

## 工具执行（输入、原始结果、可见结果）

### tool:scripted\_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d

```json
{
  "id": "tool:scripted_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d",
  "source_events": [
    {
      "seq": 7,
      "event_id": "ba6aef22-737a-4d50-811d-df03b391f8af",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:43.095Z",
      "monotonic_ms": 77.47789999999986,
      "payload_ref": {
        "sha256": "3267da8e5805b45fe23aa039d2f12c05ba72ca57abecedf4bf7c983086f0e043",
        "path": "blobs/3267da8e5805b45fe23aa039d2f12c05ba72ca57abecedf4bf7c983086f0e043.json",
        "bytes": 184,
        "media_type": "application/json"
      }
    },
    {
      "seq": 10,
      "event_id": "c36ee571-8784-46bb-8e76-ea8332c9f9cf",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:44.695Z",
      "monotonic_ms": 1677.195999999998,
      "payload_ref": {
        "sha256": "3d9643794ce97c7132a3b979155113904b00e69e75dd8988d789e3d801f1c239",
        "path": "blobs/3d9643794ce97c7132a3b979155113904b00e69e75dd8988d789e3d801f1c239.json",
        "bytes": 105,
        "media_type": "application/json"
      }
    },
    {
      "seq": 21,
      "event_id": "9df8012e-2800-422b-a6d3-df683ac2c7b5",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:47.378Z",
      "monotonic_ms": 4359.742400000001,
      "payload_ref": {
        "sha256": "6a5fc28abda42af89fb85786ef0f521a118b40cc1b7a292d553d65c06a68bae0",
        "path": "blobs/6a5fc28abda42af89fb85786ef0f521a118b40cc1b7a292d553d65c06a68bae0.json",
        "bytes": 6998,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d",
  "modelCallId": null,
  "name": "approve_token",
  "raw_arguments": "{\"token\":\"A\",\"spender\":\"amm\",\"amount\":\"22\"}",
  "input": {
    "token": "A",
    "spender": "amm",
    "amount": "22"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "approve_token",
    "args": {
      "token": "A",
      "spender": "amm",
      "amount": "22"
    },
    "contractCallId": "08dd028d-16c3-44a1-ae40-a84087366fae",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "22",
        "baseUnits": "22000000"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "txHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d00000000000000000000000000000000000000000000000000000000014fb180",
    "value": "0",
    "nonce": 13,
    "gas": "46131",
    "type": "eip1559",
    "maxFeePerGas": "1246867388",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1180183135",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46131",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x00000000000000000000000000000000000000000000000000000000014fb180",
          "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
          "blockNumber": "14",
          "blockTimestamp": "1794810167",
          "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
      "transactionIndex": 0,
      "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
      "blockNumber": "14",
      "gasUsed": "46131",
      "effectiveGasPrice": "1180183135",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810167
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0x933477D28d204bc2D05ee5B522a245536b27D69D",
        "22000000"
      ]
    }
  },
  "visible_result": {
    "tool": "approve_token",
    "args": {
      "token": "A",
      "spender": "amm",
      "amount": "22"
    },
    "contractCallId": "08dd028d-16c3-44a1-ae40-a84087366fae",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "22",
        "baseUnits": "22000000"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "txHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d00000000000000000000000000000000000000000000000000000000014fb180",
    "value": "0",
    "nonce": 13,
    "gas": "46131",
    "type": "eip1559",
    "maxFeePerGas": "1246867388",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1180183135",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46131",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x00000000000000000000000000000000000000000000000000000000014fb180",
          "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
          "blockNumber": "14",
          "blockTimestamp": "1794810167",
          "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
      "transactionIndex": 0,
      "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
      "blockNumber": "14",
      "gasUsed": "46131",
      "effectiveGasPrice": "1180183135",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810167
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0x933477D28d204bc2D05ee5B522a245536b27D69D",
        "22000000"
      ]
    }
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 7,
    "end_seq": 21,
    "start_time": "2026-11-16T06:22:43.095Z",
    "end_time": "2026-11-16T06:22:47.378Z",
    "duration_ms": 4282.264500000001
  }
}
```


## 合约调用（读取或写交易）

### contract:08dd028d-16c3-44a1-ae40-a84087366fae

```json
{
  "id": "contract:08dd028d-16c3-44a1-ae40-a84087366fae",
  "source_events": [
    {
      "seq": 11,
      "event_id": "08b62853-57d1-43a9-a462-56086501c618",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:44.700Z",
      "monotonic_ms": 1682.2981999999993,
      "payload_ref": {
        "sha256": "3b4f73baae8482313942aa4fdfc895cee7509638c53155cddbc716a7db234b5a",
        "path": "blobs/3b4f73baae8482313942aa4fdfc895cee7509638c53155cddbc716a7db234b5a.json",
        "bytes": 930,
        "media_type": "application/json"
      }
    },
    {
      "seq": 20,
      "event_id": "91dd829a-e685-4e48-9b59-a518236187ea",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:47.376Z",
      "monotonic_ms": 4357.825299999999,
      "payload_ref": {
        "sha256": "7d7cbf15853038b0bed81a202e5a1e54867e8840963833e50f1a4c45bde63205",
        "path": "blobs/7d7cbf15853038b0bed81a202e5a1e54867e8840963833e50f1a4c45bde63205.json",
        "bytes": 3679,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "08dd028d-16c3-44a1-ae40-a84087366fae",
  "toolCallId": "scripted_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d",
  "kind": "transaction",
  "tool": "approve_token",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "label": "approve"
  },
  "function": {
    "name": "approve",
    "signature": "approve(address,uint256)",
    "selector": "0x095ea7b3",
    "args": [
      "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "22000000"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d00000000000000000000000000000000000000000000000000000000014fb180",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "22",
      "baseUnits": "22000000"
    }
  ],
  "result": {
    "tool": "approve_token",
    "args": {
      "token": "A",
      "spender": "amm",
      "amount": "22"
    },
    "contractCallId": "08dd028d-16c3-44a1-ae40-a84087366fae",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "22",
        "baseUnits": "22000000"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "txHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d00000000000000000000000000000000000000000000000000000000014fb180",
    "value": "0",
    "nonce": 13,
    "gas": "46131",
    "type": "eip1559",
    "maxFeePerGas": "1246867388",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1180183135",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46131",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x00000000000000000000000000000000000000000000000000000000014fb180",
          "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
          "blockNumber": "14",
          "blockTimestamp": "1794810167",
          "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
      "transactionIndex": 0,
      "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
      "blockNumber": "14",
      "gasUsed": "46131",
      "effectiveGasPrice": "1180183135",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810167
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0x933477D28d204bc2D05ee5B522a245536b27D69D",
        "22000000"
      ]
    }
  },
  "txHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
  "submitted": true,
  "start_end": {
    "start_seq": 11,
    "end_seq": 20,
    "start_time": "2026-11-16T06:22:44.700Z",
    "end_time": "2026-11-16T06:22:47.376Z",
    "duration_ms": 2675.5270999999993
  }
}
```


## 交易与确认状态

### transaction:0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2

```json
{
  "id": "transaction:0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
  "hash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
  "contractCallId": "08dd028d-16c3-44a1-ae40-a84087366fae",
  "toolCallId": "scripted_295b873e-f0ab-4d7b-b8fe-a3d7b9740e3d",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d00000000000000000000000000000000000000000000000000000000014fb180",
    "value": "0",
    "nonce": 13,
    "gas": "46131",
    "maxFeePerGas": "1246867388",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1180183135"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "46131",
    "logs": [
      {
        "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
        "topics": [
          "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
        ],
        "data": "0x00000000000000000000000000000000000000000000000000000000014fb180",
        "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
        "blockNumber": "14",
        "blockTimestamp": "1794810167",
        "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      }
    ],
    "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
    "transactionHash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
    "transactionIndex": 0,
    "blockHash": "0x7b2b5f9b071fe901cc525e9fc2aa991842f020cf672d9dda20f9d5c86c34a4b2",
    "blockNumber": "14",
    "gasUsed": "46131",
    "effectiveGasPrice": "1180183135",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "contractAddress": null,
    "blockTimestamp": 1794810167
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 12,
      "event_id": "50434ac7-11a6-4e4b-8901-1330b7f6bbbc",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:44.865Z",
      "monotonic_ms": 1847.2663000000011,
      "payload_ref": {
        "sha256": "5407735baa7595dd35114cb6f61b4aae1ae70e58f09e6fb21c0f566d8dfd4814",
        "path": "blobs/5407735baa7595dd35114cb6f61b4aae1ae70e58f09e6fb21c0f566d8dfd4814.json",
        "bytes": 1149,
        "media_type": "application/json"
      }
    },
    {
      "seq": 16,
      "event_id": "19d7f647-70c7-4ba6-b257-e7ac3da10460",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:47.236Z",
      "monotonic_ms": 4217.830100000001,
      "payload_ref": {
        "sha256": "1339d533f63d3c94248e35ebde8f985aa33228e8cf25a559c8ab8ee3b3454f07",
        "path": "blobs/1339d533f63d3c94248e35ebde8f985aa33228e8cf25a559c8ab8ee3b3454f07.json",
        "bytes": 1149,
        "media_type": "application/json"
      }
    },
    {
      "seq": 17,
      "event_id": "62c5137a-f45e-490d-8ae1-1e267b49cc3e",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:47.340Z",
      "monotonic_ms": 4322.395699999999,
      "payload_ref": {
        "sha256": "58bae24f19de03dd8a5e8520e1f4914d6a6e77da22b7f1f64b72d2576cac77e6",
        "path": "blobs/58bae24f19de03dd8a5e8520e1f4914d6a6e77da22b7f1f64b72d2576cac77e6.json",
        "bytes": 3296,
        "media_type": "application/json"
      }
    },
    {
      "seq": 19,
      "event_id": "c4642e85-e7b7-49e7-ae9a-ac9da8ce8c88",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:47.372Z",
      "monotonic_ms": 4354.488500000001,
      "payload_ref": {
        "sha256": "ee652ff334f796d5af2fa0534b1597bf2adf59ed268732e2f5ce7dfbc66ea5fa",
        "path": "blobs/ee652ff334f796d5af2fa0534b1597bf2adf59ed268732e2f5ce7dfbc66ea5fa.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    },
    {
      "seq": 25,
      "event_id": "07700d54-fce1-45ab-a17f-7a8440ce216f",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:47.725Z",
      "monotonic_ms": 4707.433500000001,
      "payload_ref": {
        "sha256": "46e1534ac99d4d1b2f6d1ed1c207373aa7d22a03141d78336c11a735cfb4b153",
        "path": "blobs/46e1534ac99d4d1b2f6d1ed1c207373aa7d22a03141d78336c11a735cfb4b153.json",
        "bytes": 12624,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "22",
      "baseUnits": "22000000"
    }
  ],
  "decoded": {
    "functionName": "approve",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D",
      "22000000"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 12,
    "end_seq": 25,
    "start_time": "2026-11-16T06:22:44.865Z",
    "end_time": "2026-11-16T06:22:47.725Z",
    "duration_ms": 2860.1672
  }
}
```


## 内部EVM调用帧（callTracer父子树）

### evm:c4642e85-e7b7-49e7-ae9a-ac9da8ce8c88%2F0

```json
{
  "id": "evm:c4642e85-e7b7-49e7-ae9a-ac9da8ce8c88%2F0",
  "callId": "evm:c4642e85-e7b7-49e7-ae9a-ac9da8ce8c88%2F0",
  "parentId": null,
  "transaction_id": "transaction:0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
  "hash": "0xf984ab454a6937470d8e90dcbf001df36fe7333bbb78c5ae037f6c5f9c50e2e2",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d00000000000000000000000000000000000000000000000000000000014fb180",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x5fcb",
  "gasUsed": "0xb433",
  "function": {
    "name": "approve",
    "signature": "approve(address,uint256)",
    "selector": "0x095ea7b3",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D",
      "22000000"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 19,
      "event_id": "c4642e85-e7b7-49e7-ae9a-ac9da8ce8c88",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:47.372Z",
      "monotonic_ms": 4354.488500000001,
      "payload_ref": {
        "sha256": "ee652ff334f796d5af2fa0534b1597bf2adf59ed268732e2f5ce7dfbc66ea5fa",
        "path": "blobs/ee652ff334f796d5af2fa0534b1597bf2adf59ed268732e2f5ce7dfbc66ea5fa.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 19,
    "end_seq": 19,
    "start_time": "2026-11-16T06:22:47.372Z",
    "end_time": "2026-11-16T06:22:47.372Z",
    "duration_ms": 0
  }
}
```


## 缺失与注意事项

未发现构建阶段结构警告。原始文件哈希核验由导出调用方负责；轨迹本身不判定任务成功。
