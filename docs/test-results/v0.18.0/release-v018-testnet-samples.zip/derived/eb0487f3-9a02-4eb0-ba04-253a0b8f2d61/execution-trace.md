# Web3 Agent 执行轨迹

运行编号：eb0487f3-9a02-4eb0-ba04-253a0b8f2d61

本文件由原始事件生成，用于查看执行关系。列表的记录顺序不代表因果关系；只有显式调用ID、交易哈希与callTracer父子关系形成连线。内部EVM调用是链执行证据，不是模型思维过程。

完整结构见同目录 execution-trace.json；模型原始完整响应body与工具原始记录通过 source_events.payload_ref 指向原始 blobs 文件。本文件不截断已展开实体。

## 任务与来源

```json
{
  "task": {
    "node_id": "task:eb0487f3-9a02-4eb0-ba04-253a0b8f2d61",
    "id": "approve",
    "input": "将agent的TokenA对实验amm的allowance设置为恰好20 TokenA。正确调用参数为{\"token\":\"A\",\"spender\":\"amm\",\"amount\":\"20\"}，不要乘代币精度。approve是覆盖设置而非增加；已有授权恰好20时可不提交交易。查看状态时优先读取formatted.allowances.ammA中的代币数量。",
    "mode": "scripted",
    "experiment_mode": "continuous",
    "amount_validation": "fixed_task",
    "data_origin": "scripted",
    "allowed_tools": [
      "get_balance",
      "get_state",
      "approve_token"
    ],
    "source_events": [
      {
        "seq": 4,
        "event_id": "8b22e160-d000-4b55-afbc-4efd266f1a97",
        "type": "agent.start",
        "timestamp": "2026-11-16T06:22:39.101Z",
        "monotonic_ms": 36.42559999999867,
        "payload_ref": {
          "sha256": "6ce358863a310268aa8838dc15e978177ab8dbecc9d7ed775cd1db2f22ffc82f",
          "path": "blobs/6ce358863a310268aa8838dc15e978177ab8dbecc9d7ed775cd1db2f22ffc82f.json",
          "bytes": 3148,
          "media_type": "application/json"
        }
      }
    ],
    "task_parameters": {
      "amount": "20"
    },
    "parameter_source": "structured",
    "continuation_of": null
  },
  "provenance": {
    "kind": "derived",
    "source": "original_events",
    "builder_version": "1.2",
    "manifest_present": true,
    "recording_status": "complete",
    "sealed_at": "2026-11-16T06:22:39.777Z",
    "event_count": 22,
    "events_sha256": "1b1d22c933bd7f4064334c7f7122eeffe0f3cc2f5b046ff460e2641113192965",
    "integrity": "raw_manifest_verified_before_derivation",
    "source_manifest_sha256": "ef22ae822f1dd6cb4e900d8407a08ec0ca65c345c33222fafd3b387fe8ad41b0"
  },
  "summary": {
    "model_call_count": 0,
    "model_proposal_count": 0,
    "tool_call_count": 1,
    "tool_record_count": 1,
    "contract_call_count": 1,
    "explicit_contract_call_count": 1,
    "transaction_count": 1,
    "call_frame_count": 1,
    "edge_count": 5,
    "transaction_status_counts": {
      "success": 1
    },
    "model_used": false,
    "internal_trace_meaning": "EVM execution evidence; not model reasoning",
    "completeness": "recorded_events_only"
  }
}
```

## 步骤关系表

| 来源节点 | 关系 | 目标节点 | 原始事件序号 |
| --- | --- | --- | --- |
| task:eb0487f3-9a02-4eb0-ba04-253a0b8f2d61 | scripted\_task\_step | tool:scripted\_45b9d651-7939-4df2-985a-ce40d8ebfb48 | 6 |
| tool:scripted\_45b9d651-7939-4df2-985a-ce40d8ebfb48 | invokes\_contract | contract:acd58444-80cb-406b-bea7-700977bbac5a | 9, 16 |
| transaction:0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed | evm\_trace\_root | evm:2a3d398b-8957-41f5-b099-8480d4de0855%2F0 | 15 |
| contract:acd58444-80cb-406b-bea7-700977bbac5a | submits\_transaction | transaction:0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed | 12, 13, 21 |
| tool:scripted\_45b9d651-7939-4df2-985a-ce40d8ebfb48 | submits\_transaction | transaction:0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed | 12, 13, 21 |

## 模型接口调用与提议（提议不等于工具执行）

没有记录到此类实体；不能据此补造调用。

## 工具执行（输入、原始结果、可见结果）

### tool:scripted\_45b9d651-7939-4df2-985a-ce40d8ebfb48

```json
{
  "id": "tool:scripted_45b9d651-7939-4df2-985a-ce40d8ebfb48",
  "source_events": [
    {
      "seq": 7,
      "event_id": "422b238b-31b6-471b-84a6-7fa38e08addf",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:39.107Z",
      "monotonic_ms": 42.96099999999933,
      "payload_ref": {
        "sha256": "c778fa6b202b794ce75dcb26eb7c4cd66a6b1dfe75e0eaba34a089f803075dc4",
        "path": "blobs/c778fa6b202b794ce75dcb26eb7c4cd66a6b1dfe75e0eaba34a089f803075dc4.json",
        "bytes": 184,
        "media_type": "application/json"
      }
    },
    {
      "seq": 8,
      "event_id": "149c6960-10ed-41c7-8dbc-7b0cf862a943",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:39.109Z",
      "monotonic_ms": 44.60069999999905,
      "payload_ref": {
        "sha256": "460eb2b901bfa8ac09bbaae049a6c2d35892e6e30c29c2ce5e0a26671fca40aa",
        "path": "blobs/460eb2b901bfa8ac09bbaae049a6c2d35892e6e30c29c2ce5e0a26671fca40aa.json",
        "bytes": 105,
        "media_type": "application/json"
      }
    },
    {
      "seq": 17,
      "event_id": "3c598dec-8716-431a-8f6b-49420a56daac",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:39.528Z",
      "monotonic_ms": 463.35059999999976,
      "payload_ref": {
        "sha256": "7a392d3aa504832e150a3a3283b971a0573d7a10aaf647287586a42edad209a3",
        "path": "blobs/7a392d3aa504832e150a3a3283b971a0573d7a10aaf647287586a42edad209a3.json",
        "bytes": 6992,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_45b9d651-7939-4df2-985a-ce40d8ebfb48",
  "modelCallId": null,
  "name": "approve_token",
  "raw_arguments": "{\"token\":\"A\",\"spender\":\"amm\",\"amount\":\"20\"}",
  "input": {
    "token": "A",
    "spender": "amm",
    "amount": "20"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "approve_token",
    "args": {
      "token": "A",
      "spender": "amm",
      "amount": "20"
    },
    "contractCallId": "acd58444-80cb-406b-bea7-700977bbac5a",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "20",
        "baseUnits": "20000000"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "txHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000001312d00",
    "value": "0",
    "nonce": 8,
    "gas": "46119",
    "type": "eip1559",
    "maxFeePerGas": "1480006813",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1350177321",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46119",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000001312d00",
          "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
          "blockNumber": "9",
          "blockTimestamp": "1794810159",
          "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
      "transactionIndex": 0,
      "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
      "blockNumber": "9",
      "gasUsed": "46119",
      "effectiveGasPrice": "1350177321",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810159
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0x933477D28d204bc2D05ee5B522a245536b27D69D",
        "20000000"
      ]
    }
  },
  "visible_result": {
    "tool": "approve_token",
    "args": {
      "token": "A",
      "spender": "amm",
      "amount": "20"
    },
    "contractCallId": "acd58444-80cb-406b-bea7-700977bbac5a",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "20",
        "baseUnits": "20000000"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "txHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000001312d00",
    "value": "0",
    "nonce": 8,
    "gas": "46119",
    "type": "eip1559",
    "maxFeePerGas": "1480006813",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1350177321",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46119",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000001312d00",
          "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
          "blockNumber": "9",
          "blockTimestamp": "1794810159",
          "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
      "transactionIndex": 0,
      "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
      "blockNumber": "9",
      "gasUsed": "46119",
      "effectiveGasPrice": "1350177321",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810159
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0x933477D28d204bc2D05ee5B522a245536b27D69D",
        "20000000"
      ]
    }
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 7,
    "end_seq": 17,
    "start_time": "2026-11-16T06:22:39.107Z",
    "end_time": "2026-11-16T06:22:39.528Z",
    "duration_ms": 420.3896000000004
  }
}
```


## 合约调用（读取或写交易）

### contract:acd58444-80cb-406b-bea7-700977bbac5a

```json
{
  "id": "contract:acd58444-80cb-406b-bea7-700977bbac5a",
  "source_events": [
    {
      "seq": 9,
      "event_id": "439be075-7539-44e2-8a64-698d8adbf9ab",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:39.131Z",
      "monotonic_ms": 66.73219999999856,
      "payload_ref": {
        "sha256": "84791450d87afed57ddaa0484fd4edc4cecd8cccf2b47f4d0caa0fd02d12c63b",
        "path": "blobs/84791450d87afed57ddaa0484fd4edc4cecd8cccf2b47f4d0caa0fd02d12c63b.json",
        "bytes": 930,
        "media_type": "application/json"
      }
    },
    {
      "seq": 16,
      "event_id": "48a68aa7-3184-4384-a271-8c0cb0a038a2",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:39.526Z",
      "monotonic_ms": 461.53579999999965,
      "payload_ref": {
        "sha256": "e6890dc2ed25ce3391a0679a044ba80f6a5abd316aca65a2e23ae434de5452c8",
        "path": "blobs/e6890dc2ed25ce3391a0679a044ba80f6a5abd316aca65a2e23ae434de5452c8.json",
        "bytes": 3676,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "acd58444-80cb-406b-bea7-700977bbac5a",
  "toolCallId": "scripted_45b9d651-7939-4df2-985a-ce40d8ebfb48",
  "kind": "transaction",
  "tool": "approve_token",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "label": "approve"
  },
  "function": {
    "name": "approve",
    "signature": "approve(address,uint256)",
    "selector": "0x095ea7b3",
    "args": [
      "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "20000000"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000001312d00",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "20",
      "baseUnits": "20000000"
    }
  ],
  "result": {
    "tool": "approve_token",
    "args": {
      "token": "A",
      "spender": "amm",
      "amount": "20"
    },
    "contractCallId": "acd58444-80cb-406b-bea7-700977bbac5a",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "20",
        "baseUnits": "20000000"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "txHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000001312d00",
    "value": "0",
    "nonce": 8,
    "gas": "46119",
    "type": "eip1559",
    "maxFeePerGas": "1480006813",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1350177321",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46119",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000001312d00",
          "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
          "blockNumber": "9",
          "blockTimestamp": "1794810159",
          "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
      "transactionIndex": 0,
      "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
      "blockNumber": "9",
      "gasUsed": "46119",
      "effectiveGasPrice": "1350177321",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
      "contractAddress": null,
      "blockTimestamp": 1794810159
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0x933477D28d204bc2D05ee5B522a245536b27D69D",
        "20000000"
      ]
    }
  },
  "txHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
  "submitted": true,
  "start_end": {
    "start_seq": 9,
    "end_seq": 16,
    "start_time": "2026-11-16T06:22:39.131Z",
    "end_time": "2026-11-16T06:22:39.526Z",
    "duration_ms": 394.8036000000011
  }
}
```


## 交易与确认状态

### transaction:0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed

```json
{
  "id": "transaction:0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
  "hash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
  "contractCallId": "acd58444-80cb-406b-bea7-700977bbac5a",
  "toolCallId": "scripted_45b9d651-7939-4df2-985a-ce40d8ebfb48",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "data": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000001312d00",
    "value": "0",
    "nonce": 8,
    "gas": "46119",
    "maxFeePerGas": "1480006813",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1350177321"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "46119",
    "logs": [
      {
        "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
        "topics": [
          "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
        ],
        "data": "0x0000000000000000000000000000000000000000000000000000000001312d00",
        "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
        "blockNumber": "9",
        "blockTimestamp": "1794810159",
        "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      }
    ],
    "logsBloom": "0x00000400000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000100000200000100040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000400000000000000000000800000020000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
    "transactionHash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
    "transactionIndex": 0,
    "blockHash": "0xbbbb1b0e54952c964bc8b057cc2c6da897781a32d52a6757292335cae9ee55ee",
    "blockNumber": "9",
    "gasUsed": "46119",
    "effectiveGasPrice": "1350177321",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
    "contractAddress": null,
    "blockTimestamp": 1794810159
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 10,
      "event_id": "109cc091-f0e7-4c6c-a3f7-dcb142d3f99b",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:39.327Z",
      "monotonic_ms": 262.6207999999988,
      "payload_ref": {
        "sha256": "bebc005f310c9e9bb71907dd3ba1964f6c062b8fb7856f39c460ffa8ceda2e32",
        "path": "blobs/bebc005f310c9e9bb71907dd3ba1964f6c062b8fb7856f39c460ffa8ceda2e32.json",
        "bytes": 1148,
        "media_type": "application/json"
      }
    },
    {
      "seq": 12,
      "event_id": "d661e041-2606-4fc7-bb67-2a2bfa258003",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:39.381Z",
      "monotonic_ms": 316.6871999999985,
      "payload_ref": {
        "sha256": "dc37fa89ce0d4b69c2f27cbe507ccd02f43922f839847f44997032ffcdfa666a",
        "path": "blobs/dc37fa89ce0d4b69c2f27cbe507ccd02f43922f839847f44997032ffcdfa666a.json",
        "bytes": 1148,
        "media_type": "application/json"
      }
    },
    {
      "seq": 13,
      "event_id": "62dfb975-aaca-4d63-b274-ac17c72694ff",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:39.507Z",
      "monotonic_ms": 442.72549999999865,
      "payload_ref": {
        "sha256": "4ac40eecb2ddc4cfd5a00ea6e88208cb457b8f86616d3a4cac86f8ba78c1db2e",
        "path": "blobs/4ac40eecb2ddc4cfd5a00ea6e88208cb457b8f86616d3a4cac86f8ba78c1db2e.json",
        "bytes": 3293,
        "media_type": "application/json"
      }
    },
    {
      "seq": 15,
      "event_id": "2a3d398b-8957-41f5-b099-8480d4de0855",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:39.522Z",
      "monotonic_ms": 457.85269999999946,
      "payload_ref": {
        "sha256": "2028eb99bfb29b3426f741caac4188845c0bc0107d1ed868f692e6f2b12df49a",
        "path": "blobs/2028eb99bfb29b3426f741caac4188845c0bc0107d1ed868f692e6f2b12df49a.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    },
    {
      "seq": 21,
      "event_id": "98a578e0-59c4-4463-ac79-dcdb32234b3d",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:39.763Z",
      "monotonic_ms": 698.5087999999996,
      "payload_ref": {
        "sha256": "2ee6bfab3941043aa3752237a78621d9519cd98dd51a7225778cedae716e4495",
        "path": "blobs/2ee6bfab3941043aa3752237a78621d9519cd98dd51a7225778cedae716e4495.json",
        "bytes": 12521,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "20",
      "baseUnits": "20000000"
    }
  ],
  "decoded": {
    "functionName": "approve",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D",
      "20000000"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 10,
    "end_seq": 21,
    "start_time": "2026-11-16T06:22:39.327Z",
    "end_time": "2026-11-16T06:22:39.763Z",
    "duration_ms": 435.88800000000083
  }
}
```


## 内部EVM调用帧（callTracer父子树）

### evm:2a3d398b-8957-41f5-b099-8480d4de0855%2F0

```json
{
  "id": "evm:2a3d398b-8957-41f5-b099-8480d4de0855%2F0",
  "callId": "evm:2a3d398b-8957-41f5-b099-8480d4de0855%2F0",
  "parentId": null,
  "transaction_id": "transaction:0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
  "hash": "0x1f9a82b799627a347c016dd25322e63773c144d27598f08d54d5f52cf4184aed",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0x095ea7b3000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000001312d00",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x5fcb",
  "gasUsed": "0xb427",
  "function": {
    "name": "approve",
    "signature": "approve(address,uint256)",
    "selector": "0x095ea7b3",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D",
      "20000000"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "2a3d398b-8957-41f5-b099-8480d4de0855",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:39.522Z",
      "monotonic_ms": 457.85269999999946,
      "payload_ref": {
        "sha256": "2028eb99bfb29b3426f741caac4188845c0bc0107d1ed868f692e6f2b12df49a",
        "path": "blobs/2028eb99bfb29b3426f741caac4188845c0bc0107d1ed868f692e6f2b12df49a.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:39.522Z",
    "end_time": "2026-11-16T06:22:39.522Z",
    "duration_ms": 0
  }
}
```


## 缺失与注意事项

未发现构建阶段结构警告。原始文件哈希核验由导出调用方负责；轨迹本身不判定任务成功。
