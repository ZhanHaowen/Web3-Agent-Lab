# Web3 Agent 执行轨迹

运行编号：a1608c1a-0b9d-41d8-8c2e-07eed7174e01

本文件由原始事件生成，用于查看执行关系。列表的记录顺序不代表因果关系；只有显式调用ID、交易哈希与callTracer父子关系形成连线。内部EVM调用是链执行证据，不是模型思维过程。

完整结构见同目录 execution-trace.json；模型原始完整响应body与工具原始记录通过 source_events.payload_ref 指向原始 blobs 文件。本文件不截断已展开实体。

## 任务与来源

```json
{
  "task": {
    "node_id": "task:a1608c1a-0b9d-41d8-8c2e-07eed7174e01",
    "id": "swap_deposit",
    "input": "使用实验amm将10 TokenA兑换为TokenB（至少9 TokenB），随后只将本次兑换新增的TokenB全部存入实验vault，份额归agent；保留运行前已有的TokenB和份额。用兑换后的B余额减去本次initialState中的B余额确定新增数量，或核对成功兑换的amountOut。先按需授权：已有allowance足够则跳过，否则设置为本次所需数量。工具amount/amountIn/minAmountOut使用十进制代币单位字符串；链状态余额和allowance为精度6的整数最小单位字符串，1 token=1000000最小单位。",
    "mode": "scripted",
    "experiment_mode": "continuous",
    "amount_validation": "fixed_task",
    "data_origin": "scripted",
    "allowed_tools": [
      "get_balance",
      "get_state",
      "approve_token",
      "swap",
      "deposit"
    ],
    "source_events": [
      {
        "seq": 4,
        "event_id": "ee2257b6-483e-4835-84aa-e7659ea6e82a",
        "type": "agent.start",
        "timestamp": "2026-11-16T06:22:41.038Z",
        "monotonic_ms": 63.16390000000138,
        "payload_ref": {
          "sha256": "2163632cc2c3a592dff303c2b3a89e9530e9ba875ee850befab0e52afa77fc36",
          "path": "blobs/2163632cc2c3a592dff303c2b3a89e9530e9ba875ee850befab0e52afa77fc36.json",
          "bytes": 5344,
          "media_type": "application/json"
        }
      }
    ],
    "task_parameters": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "parameter_source": "structured",
    "continuation_of": null
  },
  "provenance": {
    "kind": "derived",
    "source": "original_events",
    "builder_version": "1.2",
    "manifest_present": true,
    "recording_status": "complete",
    "sealed_at": "2026-11-16T06:22:42.683Z",
    "event_count": 52,
    "events_sha256": "61941f42cc433c46e33dfb015434c17142bbe29ce2548966143aa9f1b4410956",
    "integrity": "raw_manifest_verified_before_derivation",
    "source_manifest_sha256": "495c692636c553b00d9e660e79ed59d0a2fc9cd9901dbdd5a35ec2eb2cd0b0a4"
  },
  "summary": {
    "model_call_count": 0,
    "model_proposal_count": 0,
    "tool_call_count": 4,
    "tool_record_count": 4,
    "contract_call_count": 4,
    "explicit_contract_call_count": 4,
    "transaction_count": 3,
    "call_frame_count": 8,
    "edge_count": 22,
    "transaction_status_counts": {
      "success": 3
    },
    "model_used": false,
    "internal_trace_meaning": "EVM execution evidence; not model reasoning",
    "completeness": "recorded_events_only"
  }
}
```

## 步骤关系表

| 来源节点 | 关系 | 目标节点 | 原始事件序号 |
| --- | --- | --- | --- |
| task:a1608c1a-0b9d-41d8-8c2e-07eed7174e01 | scripted\_task\_step | tool:scripted\_ddfb94e7-8d18-43a1-8ffd-c3213f287675 | 6 |
| tool:scripted\_ddfb94e7-8d18-43a1-8ffd-c3213f287675 | invokes\_contract | contract:ccf66f96-781e-48f3-ba49-c30f8dd83d84 | 9, 16 |
| transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829 | evm\_trace\_root | evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0 | 15 |
| evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0 | evm\_child\_call | evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.0 | 15 |
| evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0 | evm\_child\_call | evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.1 | 15 |
| evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0 | evm\_child\_call | evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.2 | 15 |
| evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0 | evm\_child\_call | evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.3 | 15 |
| task:a1608c1a-0b9d-41d8-8c2e-07eed7174e01 | scripted\_task\_step | tool:scripted\_dd6138bc-8f4a-47df-a51d-8cd8b20b70ce | 18 |
| tool:scripted\_dd6138bc-8f4a-47df-a51d-8cd8b20b70ce | invokes\_contract | contract:e2b3dfe1-3137-4985-945e-112f53cebdd0 | 21, 22 |
| task:a1608c1a-0b9d-41d8-8c2e-07eed7174e01 | scripted\_task\_step | tool:scripted\_00cfc833-6023-48fe-ac13-811beed92fad | 24 |
| tool:scripted\_00cfc833-6023-48fe-ac13-811beed92fad | invokes\_contract | contract:2891c478-0689-48d7-b7f9-ab89e76538a2 | 27, 34 |
| transaction:0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f | evm\_trace\_root | evm:b474ec88-9529-4f09-ac70-6d24d9becc47%2F0 | 33 |
| task:a1608c1a-0b9d-41d8-8c2e-07eed7174e01 | scripted\_task\_step | tool:scripted\_440ff21c-4c84-4103-b1a4-af6ca0bb1132 | 36 |
| tool:scripted\_440ff21c-4c84-4103-b1a4-af6ca0bb1132 | invokes\_contract | contract:f321af92-cd84-48dd-a553-1eee64de4eb7 | 39, 46 |
| transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75 | evm\_trace\_root | evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0 | 45 |
| evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0 | evm\_child\_call | evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0.0 | 45 |
| contract:ccf66f96-781e-48f3-ba49-c30f8dd83d84 | submits\_transaction | transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829 | 12, 13, 51 |
| tool:scripted\_ddfb94e7-8d18-43a1-8ffd-c3213f287675 | submits\_transaction | transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829 | 12, 13, 51 |
| contract:2891c478-0689-48d7-b7f9-ab89e76538a2 | submits\_transaction | transaction:0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f | 30, 31, 51 |
| tool:scripted\_00cfc833-6023-48fe-ac13-811beed92fad | submits\_transaction | transaction:0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f | 30, 31, 51 |
| contract:f321af92-cd84-48dd-a553-1eee64de4eb7 | submits\_transaction | transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75 | 42, 43, 51 |
| tool:scripted\_440ff21c-4c84-4103-b1a4-af6ca0bb1132 | submits\_transaction | transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75 | 42, 43, 51 |

## 模型接口调用与提议（提议不等于工具执行）

没有记录到此类实体；不能据此补造调用。

## 工具执行（输入、原始结果、可见结果）

### tool:scripted\_ddfb94e7-8d18-43a1-8ffd-c3213f287675

```json
{
  "id": "tool:scripted_ddfb94e7-8d18-43a1-8ffd-c3213f287675",
  "source_events": [
    {
      "seq": 7,
      "event_id": "12bbe409-5518-4c48-aacc-8940ec06e5b3",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:41.044Z",
      "monotonic_ms": 69.51760000000104,
      "payload_ref": {
        "sha256": "648051308b185dda2b25b674a1a191f1befcbde5e21155fc20c6d3ee9befb204",
        "path": "blobs/648051308b185dda2b25b674a1a191f1befcbde5e21155fc20c6d3ee9befb204.json",
        "bytes": 164,
        "media_type": "application/json"
      }
    },
    {
      "seq": 8,
      "event_id": "5e7d3e95-44a4-48d8-b619-d9f81bdf1838",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:41.046Z",
      "monotonic_ms": 70.98140000000058,
      "payload_ref": {
        "sha256": "8ddb3f7f2738835ca015f2242455d0ee77eab953c86cd090d17c5dc5f9c0c1fe",
        "path": "blobs/8ddb3f7f2738835ca015f2242455d0ee77eab953c86cd090d17c5dc5f9c0c1fe.json",
        "bytes": 83,
        "media_type": "application/json"
      }
    },
    {
      "seq": 17,
      "event_id": "ad073f57-e80f-4d15-86b9-51a2dd81a0da",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:41.443Z",
      "monotonic_ms": 468.22140000000036,
      "payload_ref": {
        "sha256": "27569e3edbcc0f63c41a3080ef73958e3c930f4ca1304aeca7a6804fd99fe54c",
        "path": "blobs/27569e3edbcc0f63c41a3080ef73958e3c930f4ca1304aeca7a6804fd99fe54c.json",
        "bytes": 10925,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_ddfb94e7-8d18-43a1-8ffd-c3213f287675",
  "modelCallId": null,
  "name": "swap",
  "raw_arguments": "{\"amountIn\":\"10\",\"minAmountOut\":\"9\"}",
  "input": {
    "amountIn": "10",
    "minAmountOut": "9"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "swap",
    "args": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "contractCallId": "ccf66f96-781e-48f3-ba49-c30f8dd83d84",
    "amountConversions": [
      {
        "parameter": "amountIn",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      },
      {
        "parameter": "minAmountOut",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9",
        "baseUnits": "9000000"
      }
    ],
    "operation": "task:swap",
    "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "txHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 10,
    "gas": "64093",
    "type": "eip1559",
    "maxFeePerGas": "1367847685",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1268429679",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "59293",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        },
        {
          "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
          "topics": [
            "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 2,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
      "transactionIndex": 0,
      "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
      "blockNumber": "11",
      "gasUsed": "59293",
      "effectiveGasPrice": "1268429679",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "contractAddress": null,
      "blockTimestamp": 1794810161
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "swap",
      "args": [
        "10000000",
        "9000000",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    },
    "amountOut": "9940219",
    "amountOutFormatted": "9.940219"
  },
  "visible_result": {
    "tool": "swap",
    "args": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "contractCallId": "ccf66f96-781e-48f3-ba49-c30f8dd83d84",
    "amountConversions": [
      {
        "parameter": "amountIn",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      },
      {
        "parameter": "minAmountOut",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9",
        "baseUnits": "9000000"
      }
    ],
    "operation": "task:swap",
    "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "txHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 10,
    "gas": "64093",
    "type": "eip1559",
    "maxFeePerGas": "1367847685",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1268429679",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "59293",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        },
        {
          "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
          "topics": [
            "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 2,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
      "transactionIndex": 0,
      "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
      "blockNumber": "11",
      "gasUsed": "59293",
      "effectiveGasPrice": "1268429679",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "contractAddress": null,
      "blockTimestamp": 1794810161
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "swap",
      "args": [
        "10000000",
        "9000000",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    },
    "amountOut": "9940219",
    "amountOutFormatted": "9.940219"
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 7,
    "end_seq": 17,
    "start_time": "2026-11-16T06:22:41.044Z",
    "end_time": "2026-11-16T06:22:41.443Z",
    "duration_ms": 398.7037999999993
  }
}
```

### tool:scripted\_dd6138bc-8f4a-47df-a51d-8cd8b20b70ce

```json
{
  "id": "tool:scripted_dd6138bc-8f4a-47df-a51d-8cd8b20b70ce",
  "source_events": [
    {
      "seq": 19,
      "event_id": "60bdd135-a4dc-443f-b916-394a2d6ecccb",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:41.450Z",
      "monotonic_ms": 474.9853000000003,
      "payload_ref": {
        "sha256": "2caa17c45c74f529fecc01a2169e49d97cf3a6a84c087978a2e5668be995588f",
        "path": "blobs/2caa17c45c74f529fecc01a2169e49d97cf3a6a84c087978a2e5668be995588f.json",
        "bytes": 166,
        "media_type": "application/json"
      }
    },
    {
      "seq": 20,
      "event_id": "c8cdb8f1-f914-457e-8123-f24730613a12",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:41.451Z",
      "monotonic_ms": 476.3631000000005,
      "payload_ref": {
        "sha256": "19005db2260f5d7ac6d12d2cc1527013b9189ea228f294c009935bd315299e8a",
        "path": "blobs/19005db2260f5d7ac6d12d2cc1527013b9189ea228f294c009935bd315299e8a.json",
        "bytes": 85,
        "media_type": "application/json"
      }
    },
    {
      "seq": 23,
      "event_id": "66fcc26c-67ba-42d4-a6ca-36d97d6175cc",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:41.556Z",
      "monotonic_ms": 581.3665000000001,
      "payload_ref": {
        "sha256": "653f2409356a67540e52988b69c82b1c5b4a9de37b476a70e295eb5ade485482",
        "path": "blobs/653f2409356a67540e52988b69c82b1c5b4a9de37b476a70e295eb5ade485482.json",
        "bytes": 844,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_dd6138bc-8f4a-47df-a51d-8cd8b20b70ce",
  "modelCallId": null,
  "name": "get_balance",
  "raw_arguments": "{\"token\":\"B\",\"account\":\"agent\"}",
  "input": {
    "token": "B",
    "account": "agent"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "get_balance",
    "token": "B",
    "account": "agent",
    "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "balance": "19900288",
    "formatted": "19.900288",
    "decimals": 6,
    "blockNumber": "11",
    "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
    "contractCallId": "e2b3dfe1-3137-4985-945e-112f53cebdd0"
  },
  "visible_result": {
    "tool": "get_balance",
    "token": "B",
    "account": "agent",
    "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "balance": "19900288",
    "formatted": "19.900288",
    "decimals": 6,
    "blockNumber": "11",
    "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
    "contractCallId": "e2b3dfe1-3137-4985-945e-112f53cebdd0"
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 19,
    "end_seq": 23,
    "start_time": "2026-11-16T06:22:41.450Z",
    "end_time": "2026-11-16T06:22:41.556Z",
    "duration_ms": 106.38119999999981
  }
}
```

### tool:scripted\_00cfc833-6023-48fe-ac13-811beed92fad

```json
{
  "id": "tool:scripted_00cfc833-6023-48fe-ac13-811beed92fad",
  "source_events": [
    {
      "seq": 25,
      "event_id": "b48046bc-eefe-4ee2-acc2-70017d4d72c4",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:41.560Z",
      "monotonic_ms": 585.4001000000007,
      "payload_ref": {
        "sha256": "75fd681da1cb810333d414d91f7716a73205d37284606c3e4221ff6ce3d8a786",
        "path": "blobs/75fd681da1cb810333d414d91f7716a73205d37284606c3e4221ff6ce3d8a786.json",
        "bytes": 192,
        "media_type": "application/json"
      }
    },
    {
      "seq": 26,
      "event_id": "b236f634-2f08-486f-a063-5a26df49ceea",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:41.561Z",
      "monotonic_ms": 586.8575000000001,
      "payload_ref": {
        "sha256": "d9a0c6558153d89736a7b0d52ac17119a827c99ec18bba98f71bc8acc87ea4fc",
        "path": "blobs/d9a0c6558153d89736a7b0d52ac17119a827c99ec18bba98f71bc8acc87ea4fc.json",
        "bytes": 113,
        "media_type": "application/json"
      }
    },
    {
      "seq": 35,
      "event_id": "1e62552b-e1b4-45b5-92da-cb69987bbff2",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:41.986Z",
      "monotonic_ms": 1011.7813000000006,
      "payload_ref": {
        "sha256": "e07866a0df66b0da4df9e8118c8b869507f6b43797e0ea81995708aea1035f97",
        "path": "blobs/e07866a0df66b0da4df9e8118c8b869507f6b43797e0ea81995708aea1035f97.json",
        "bytes": 7022,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_00cfc833-6023-48fe-ac13-811beed92fad",
  "modelCallId": null,
  "name": "approve_token",
  "raw_arguments": "{\"token\":\"B\",\"spender\":\"vault\",\"amount\":\"9.940219\"}",
  "input": {
    "token": "B",
    "spender": "vault",
    "amount": "9.940219"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "approve_token",
    "args": {
      "token": "B",
      "spender": "vault",
      "amount": "9.940219"
    },
    "contractCallId": "2891c478-0689-48d7-b7f9-ab89e76538a2",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9.940219",
        "baseUnits": "9940219"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "txHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "data": "0x095ea7b3000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
    "value": "0",
    "nonce": 11,
    "gas": "46107",
    "type": "eip1559",
    "maxFeePerGas": "1322115614",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1235008603",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46107",
      "logs": [
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
          "blockNumber": "12",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000200000000840000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000020000000000000000000000000010000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
      "transactionIndex": 0,
      "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
      "blockNumber": "12",
      "gasUsed": "46107",
      "effectiveGasPrice": "1235008603",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
      "contractAddress": null,
      "blockTimestamp": 1794810161
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0xA4c8CC45fEd2587d4B9120f296a5c7c379C400EC",
        "9940219"
      ]
    }
  },
  "visible_result": {
    "tool": "approve_token",
    "args": {
      "token": "B",
      "spender": "vault",
      "amount": "9.940219"
    },
    "contractCallId": "2891c478-0689-48d7-b7f9-ab89e76538a2",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9.940219",
        "baseUnits": "9940219"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "txHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "data": "0x095ea7b3000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
    "value": "0",
    "nonce": 11,
    "gas": "46107",
    "type": "eip1559",
    "maxFeePerGas": "1322115614",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1235008603",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46107",
      "logs": [
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
          "blockNumber": "12",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000200000000840000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000020000000000000000000000000010000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
      "transactionIndex": 0,
      "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
      "blockNumber": "12",
      "gasUsed": "46107",
      "effectiveGasPrice": "1235008603",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
      "contractAddress": null,
      "blockTimestamp": 1794810161
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0xA4c8CC45fEd2587d4B9120f296a5c7c379C400EC",
        "9940219"
      ]
    }
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 25,
    "end_seq": 35,
    "start_time": "2026-11-16T06:22:41.560Z",
    "end_time": "2026-11-16T06:22:41.986Z",
    "duration_ms": 426.3811999999998
  }
}
```

### tool:scripted\_440ff21c-4c84-4103-b1a4-af6ca0bb1132

```json
{
  "id": "tool:scripted_440ff21c-4c84-4103-b1a4-af6ca0bb1132",
  "source_events": [
    {
      "seq": 37,
      "event_id": "aea5ba11-7363-4e7b-83ca-d52383be6e7a",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:41.991Z",
      "monotonic_ms": 1016.8514000000014,
      "payload_ref": {
        "sha256": "f8617e113917b32d6f636f0f34dd370f503a5224ef91402de54aad01227426ff",
        "path": "blobs/f8617e113917b32d6f636f0f34dd370f503a5224ef91402de54aad01227426ff.json",
        "bytes": 148,
        "media_type": "application/json"
      }
    },
    {
      "seq": 38,
      "event_id": "5e2a89a0-3d44-4358-bb00-0cf0443a0fa6",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:41.993Z",
      "monotonic_ms": 1018.0291000000016,
      "payload_ref": {
        "sha256": "008a07d5a7e21f65308f07de8819f725c84bced95403f9b06ec3004911757253",
        "path": "blobs/008a07d5a7e21f65308f07de8819f725c84bced95403f9b06ec3004911757253.json",
        "bytes": 65,
        "media_type": "application/json"
      }
    },
    {
      "seq": 47,
      "event_id": "c4d9476c-2c57-4c27-8a5f-8d9be540dc0b",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:42.264Z",
      "monotonic_ms": 1289.4098000000013,
      "payload_ref": {
        "sha256": "fa809332dee2a885ef338d8375000e6b5317481dd1d194bcc898de1a3d15231e",
        "path": "blobs/fa809332dee2a885ef338d8375000e6b5317481dd1d194bcc898de1a3d15231e.json",
        "bytes": 8646,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_440ff21c-4c84-4103-b1a4-af6ca0bb1132",
  "modelCallId": null,
  "name": "deposit",
  "raw_arguments": "{\"amount\":\"9.940219\"}",
  "input": {
    "amount": "9.940219"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "deposit",
    "args": {
      "amount": "9.940219"
    },
    "contractCallId": "f321af92-cd84-48dd-a553-1eee64de4eb7",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9.940219",
        "baseUnits": "9940219"
      }
    ],
    "operation": "task:deposit",
    "hash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "txHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "data": "0x6e553f65000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 12,
    "gas": "107266",
    "type": "eip1559",
    "maxFeePerGas": "1282010323",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1205722824",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "102466",
      "logs": [
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
          "blockNumber": "13",
          "blockTimestamp": "1794810162",
          "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
          "topics": [
            "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
          "blockNumber": "13",
          "blockTimestamp": "1794810162",
          "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000000080000840400000000000000008000000000000000000000000000000000000000000000000100000000000000000100000000800000004000000000010000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000010000000000000000000000000000000000000000402000000000000000000000000000000000008000000000000000000000000000000000000004000000000000000000000000000000000000000000000",
      "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
      "transactionIndex": 0,
      "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
      "blockNumber": "13",
      "gasUsed": "102466",
      "effectiveGasPrice": "1205722824",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
      "contractAddress": null,
      "blockTimestamp": 1794810162
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "deposit",
      "args": [
        "9940219",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    }
  },
  "visible_result": {
    "tool": "deposit",
    "args": {
      "amount": "9.940219"
    },
    "contractCallId": "f321af92-cd84-48dd-a553-1eee64de4eb7",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9.940219",
        "baseUnits": "9940219"
      }
    ],
    "operation": "task:deposit",
    "hash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "txHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "data": "0x6e553f65000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 12,
    "gas": "107266",
    "type": "eip1559",
    "maxFeePerGas": "1282010323",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1205722824",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "102466",
      "logs": [
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
          "blockNumber": "13",
          "blockTimestamp": "1794810162",
          "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
          "topics": [
            "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
          "blockNumber": "13",
          "blockTimestamp": "1794810162",
          "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000000080000840400000000000000008000000000000000000000000000000000000000000000000100000000000000000100000000800000004000000000010000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000010000000000000000000000000000000000000000402000000000000000000000000000000000008000000000000000000000000000000000000004000000000000000000000000000000000000000000000",
      "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
      "transactionIndex": 0,
      "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
      "blockNumber": "13",
      "gasUsed": "102466",
      "effectiveGasPrice": "1205722824",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
      "contractAddress": null,
      "blockTimestamp": 1794810162
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "deposit",
      "args": [
        "9940219",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    }
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 37,
    "end_seq": 47,
    "start_time": "2026-11-16T06:22:41.991Z",
    "end_time": "2026-11-16T06:22:42.264Z",
    "duration_ms": 272.5583999999999
  }
}
```


## 合约调用（读取或写交易）

### contract:ccf66f96-781e-48f3-ba49-c30f8dd83d84

```json
{
  "id": "contract:ccf66f96-781e-48f3-ba49-c30f8dd83d84",
  "source_events": [
    {
      "seq": 9,
      "event_id": "4e472e21-2549-4203-bc25-4e519ef2a961",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:41.074Z",
      "monotonic_ms": 99.36419999999998,
      "payload_ref": {
        "sha256": "9a8a30be0a8163a44b031eb2b03eac105773b85fb11979226b93f8a2ff74c76a",
        "path": "blobs/9a8a30be0a8163a44b031eb2b03eac105773b85fb11979226b93f8a2ff74c76a.json",
        "bytes": 1164,
        "media_type": "application/json"
      }
    },
    {
      "seq": 16,
      "event_id": "eb3266bc-d2d4-4e5a-8273-f614268e8d3c",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:41.441Z",
      "monotonic_ms": 466.4508000000005,
      "payload_ref": {
        "sha256": "2211ccd2d086472d6743fa1b9083a4c378041caee991743a7e7f5e9f30f27d1a",
        "path": "blobs/2211ccd2d086472d6743fa1b9083a4c378041caee991743a7e7f5e9f30f27d1a.json",
        "bytes": 5647,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "ccf66f96-781e-48f3-ba49-c30f8dd83d84",
  "toolCallId": "scripted_ddfb94e7-8d18-43a1-8ffd-c3213f287675",
  "kind": "transaction",
  "tool": "swap",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "label": "swap"
  },
  "function": {
    "name": "swap",
    "signature": "swap(uint256,uint256,address)",
    "selector": "0x6d9a640a",
    "args": [
      "10000000",
      "9000000",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amountIn",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "10",
      "baseUnits": "10000000"
    },
    {
      "parameter": "minAmountOut",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9",
      "baseUnits": "9000000"
    }
  ],
  "result": {
    "tool": "swap",
    "args": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "contractCallId": "ccf66f96-781e-48f3-ba49-c30f8dd83d84",
    "amountConversions": [
      {
        "parameter": "amountIn",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      },
      {
        "parameter": "minAmountOut",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9",
        "baseUnits": "9000000"
      }
    ],
    "operation": "task:swap",
    "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "txHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 10,
    "gas": "64093",
    "type": "eip1559",
    "maxFeePerGas": "1367847685",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1268429679",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "59293",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        },
        {
          "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
          "topics": [
            "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
          "blockNumber": "11",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
          "transactionIndex": 0,
          "logIndex": 2,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
      "transactionIndex": 0,
      "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
      "blockNumber": "11",
      "gasUsed": "59293",
      "effectiveGasPrice": "1268429679",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "contractAddress": null,
      "blockTimestamp": 1794810161
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "swap",
      "args": [
        "10000000",
        "9000000",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    },
    "amountOut": "9940219",
    "amountOutFormatted": "9.940219"
  },
  "txHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "submitted": true,
  "start_end": {
    "start_seq": 9,
    "end_seq": 16,
    "start_time": "2026-11-16T06:22:41.074Z",
    "end_time": "2026-11-16T06:22:41.441Z",
    "duration_ms": 367.08660000000054
  }
}
```

### contract:e2b3dfe1-3137-4985-945e-112f53cebdd0

```json
{
  "id": "contract:e2b3dfe1-3137-4985-945e-112f53cebdd0",
  "source_events": [
    {
      "seq": 21,
      "event_id": "7e8b2016-4188-4921-8ce6-cf2fd758cac0",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:41.509Z",
      "monotonic_ms": 534.6798000000017,
      "payload_ref": {
        "sha256": "8acb105ef4cdc17fa735618233a80e9768e60ececafc1007e54569ffa8d17e6f",
        "path": "blobs/8acb105ef4cdc17fa735618233a80e9768e60ececafc1007e54569ffa8d17e6f.json",
        "bytes": 687,
        "media_type": "application/json"
      }
    },
    {
      "seq": 22,
      "event_id": "18ea331d-8a62-4afb-9837-3558c7a88a9c",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:41.529Z",
      "monotonic_ms": 554.7156000000014,
      "payload_ref": {
        "sha256": "b8d298dd26c58fbc952b14cd173c4bc2d2c905987ef9efd032fdf38116fca6f4",
        "path": "blobs/b8d298dd26c58fbc952b14cd173c4bc2d2c905987ef9efd032fdf38116fca6f4.json",
        "bytes": 227,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "e2b3dfe1-3137-4985-945e-112f53cebdd0",
  "toolCallId": "scripted_dd6138bc-8f4a-47df-a51d-8cd8b20b70ce",
  "kind": "read",
  "tool": "get_balance",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "label": "balanceOf"
  },
  "function": {
    "name": "balanceOf",
    "signature": "balanceOf(address)",
    "selector": "0x70a08231",
    "args": [
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "request": {
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "data": "0x70a08231000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "blockNumber": "11",
    "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989"
  },
  "result": "19900288",
  "blockNumber": "11",
  "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
  "start_end": {
    "start_seq": 21,
    "end_seq": 22,
    "start_time": "2026-11-16T06:22:41.509Z",
    "end_time": "2026-11-16T06:22:41.529Z",
    "duration_ms": 20.035799999999654
  }
}
```

### contract:2891c478-0689-48d7-b7f9-ab89e76538a2

```json
{
  "id": "contract:2891c478-0689-48d7-b7f9-ab89e76538a2",
  "source_events": [
    {
      "seq": 27,
      "event_id": "7afb8d62-51a1-45a0-b27c-026c476a4759",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:41.588Z",
      "monotonic_ms": 613.1040000000012,
      "payload_ref": {
        "sha256": "9064664c6957814f06d85589149d0400e3b3dcfc0aabd421401e928197a59e41",
        "path": "blobs/9064664c6957814f06d85589149d0400e3b3dcfc0aabd421401e928197a59e41.json",
        "bytes": 934,
        "media_type": "application/json"
      }
    },
    {
      "seq": 34,
      "event_id": "9fa056fa-8e55-4666-80ed-ed658630cb8b",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:41.984Z",
      "monotonic_ms": 1009.3906000000006,
      "payload_ref": {
        "sha256": "848b449da96b852abbe865611efb074b214571f0ccce3ab738d72e8d4d226a38",
        "path": "blobs/848b449da96b852abbe865611efb074b214571f0ccce3ab738d72e8d4d226a38.json",
        "bytes": 3691,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "2891c478-0689-48d7-b7f9-ab89e76538a2",
  "toolCallId": "scripted_00cfc833-6023-48fe-ac13-811beed92fad",
  "kind": "transaction",
  "tool": "approve_token",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "label": "approve"
  },
  "function": {
    "name": "approve",
    "signature": "approve(address,uint256)",
    "selector": "0x095ea7b3",
    "args": [
      "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
      "9940219"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "data": "0x095ea7b3000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9.940219",
      "baseUnits": "9940219"
    }
  ],
  "result": {
    "tool": "approve_token",
    "args": {
      "token": "B",
      "spender": "vault",
      "amount": "9.940219"
    },
    "contractCallId": "2891c478-0689-48d7-b7f9-ab89e76538a2",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9.940219",
        "baseUnits": "9940219"
      }
    ],
    "operation": "task:approve_token",
    "hash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "txHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "data": "0x095ea7b3000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
    "value": "0",
    "nonce": 11,
    "gas": "46107",
    "type": "eip1559",
    "maxFeePerGas": "1322115614",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1235008603",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "46107",
      "logs": [
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
          "blockNumber": "12",
          "blockTimestamp": "1794810161",
          "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000200000000840000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000020000000000000000000000000010000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
      "transactionIndex": 0,
      "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
      "blockNumber": "12",
      "gasUsed": "46107",
      "effectiveGasPrice": "1235008603",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
      "contractAddress": null,
      "blockTimestamp": 1794810161
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "approve",
      "args": [
        "0xA4c8CC45fEd2587d4B9120f296a5c7c379C400EC",
        "9940219"
      ]
    }
  },
  "txHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
  "submitted": true,
  "start_end": {
    "start_seq": 27,
    "end_seq": 34,
    "start_time": "2026-11-16T06:22:41.588Z",
    "end_time": "2026-11-16T06:22:41.984Z",
    "duration_ms": 396.28659999999945
  }
}
```

### contract:f321af92-cd84-48dd-a553-1eee64de4eb7

```json
{
  "id": "contract:f321af92-cd84-48dd-a553-1eee64de4eb7",
  "source_events": [
    {
      "seq": 39,
      "event_id": "9eecdb73-b495-40f7-b329-c05261434acf",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:42.020Z",
      "monotonic_ms": 1045.0600000000013,
      "payload_ref": {
        "sha256": "f028e66a8d25d53eb63a29ffece071b651dfb5cc2da5dd3686ae5baf85d305c3",
        "path": "blobs/f028e66a8d25d53eb63a29ffece071b651dfb5cc2da5dd3686ae5baf85d305c3.json",
        "bytes": 928,
        "media_type": "application/json"
      }
    },
    {
      "seq": 46,
      "event_id": "ceaa3030-9379-4983-b387-9db2cc150c40",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:42.262Z",
      "monotonic_ms": 1287.3093000000008,
      "payload_ref": {
        "sha256": "00725d941a4e9c305c206ac23270529d4903e6d128d79f153998efdb095c4941",
        "path": "blobs/00725d941a4e9c305c206ac23270529d4903e6d128d79f153998efdb095c4941.json",
        "bytes": 4506,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "f321af92-cd84-48dd-a553-1eee64de4eb7",
  "toolCallId": "scripted_440ff21c-4c84-4103-b1a4-af6ca0bb1132",
  "kind": "transaction",
  "tool": "deposit",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "label": "deposit"
  },
  "function": {
    "name": "deposit",
    "signature": "deposit(uint256,address)",
    "selector": "0x6e553f65",
    "args": [
      "9940219",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "data": "0x6e553f65000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9.940219",
      "baseUnits": "9940219"
    }
  ],
  "result": {
    "tool": "deposit",
    "args": {
      "amount": "9.940219"
    },
    "contractCallId": "f321af92-cd84-48dd-a553-1eee64de4eb7",
    "amountConversions": [
      {
        "parameter": "amount",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9.940219",
        "baseUnits": "9940219"
      }
    ],
    "operation": "task:deposit",
    "hash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "txHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "data": "0x6e553f65000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 12,
    "gas": "107266",
    "type": "eip1559",
    "maxFeePerGas": "1282010323",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1205722824",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "102466",
      "logs": [
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
          "blockNumber": "13",
          "blockTimestamp": "1794810162",
          "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
          "topics": [
            "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000000000000000000000000000000000000097acfb",
          "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
          "blockNumber": "13",
          "blockTimestamp": "1794810162",
          "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        }
      ],
      "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000000080000840400000000000000008000000000000000000000000000000000000000000000000100000000000000000100000000800000004000000000010000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000010000000000000000000000000000000000000000402000000000000000000000000000000000008000000000000000000000000000000000000004000000000000000000000000000000000000000000000",
      "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
      "transactionIndex": 0,
      "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
      "blockNumber": "13",
      "gasUsed": "102466",
      "effectiveGasPrice": "1205722824",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
      "contractAddress": null,
      "blockTimestamp": 1794810162
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "deposit",
      "args": [
        "9940219",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    }
  },
  "txHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "submitted": true,
  "start_end": {
    "start_seq": 39,
    "end_seq": 46,
    "start_time": "2026-11-16T06:22:42.020Z",
    "end_time": "2026-11-16T06:22:42.262Z",
    "duration_ms": 242.2492999999995
  }
}
```


## 交易与确认状态

### transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829

```json
{
  "id": "transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "contractCallId": "ccf66f96-781e-48f3-ba49-c30f8dd83d84",
  "toolCallId": "scripted_ddfb94e7-8d18-43a1-8ffd-c3213f287675",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 10,
    "gas": "64093",
    "maxFeePerGas": "1367847685",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1268429679"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "59293",
    "logs": [
      {
        "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
        "topics": [
          "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
        ],
        "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
        "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
        "blockNumber": "11",
        "blockTimestamp": "1794810161",
        "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      },
      {
        "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
        "topics": [
          "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
          "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
        ],
        "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
        "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
        "blockNumber": "11",
        "blockTimestamp": "1794810161",
        "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
        "transactionIndex": 0,
        "logIndex": 1,
        "removed": false
      },
      {
        "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
        "topics": [
          "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
        ],
        "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097acfb",
        "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
        "blockNumber": "11",
        "blockTimestamp": "1794810161",
        "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
        "transactionIndex": 0,
        "logIndex": 2,
        "removed": false
      }
    ],
    "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
    "transactionHash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
    "transactionIndex": 0,
    "blockHash": "0x57c773af543225b0ec8f4ab1eade12a75261f160e3373e9ba3c19e8616613989",
    "blockNumber": "11",
    "gasUsed": "59293",
    "effectiveGasPrice": "1268429679",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "contractAddress": null,
    "blockTimestamp": 1794810161
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 10,
      "event_id": "0dcdb8eb-e6c4-4566-9e13-bcfba80bbb00",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:41.238Z",
      "monotonic_ms": 263.1396000000004,
      "payload_ref": {
        "sha256": "4c5f50ffc1d5a2f1672cf64d6897e0a6168862bf725820dbe7a82e47d7a9007c",
        "path": "blobs/4c5f50ffc1d5a2f1672cf64d6897e0a6168862bf725820dbe7a82e47d7a9007c.json",
        "bytes": 1345,
        "media_type": "application/json"
      }
    },
    {
      "seq": 12,
      "event_id": "1950f801-500a-4949-99bb-24b3ef6fc9a4",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:41.290Z",
      "monotonic_ms": 315.20390000000043,
      "payload_ref": {
        "sha256": "3d828e0aeff6ecb4003afe0fb0712410068a49bd72dac00762bcc676d6ad3fb0",
        "path": "blobs/3d828e0aeff6ecb4003afe0fb0712410068a49bd72dac00762bcc676d6ad3fb0.json",
        "bytes": 1345,
        "media_type": "application/json"
      }
    },
    {
      "seq": 13,
      "event_id": "989e7d46-9e61-4274-b417-ffa7d4ba7215",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:41.411Z",
      "monotonic_ms": 436.57340000000113,
      "payload_ref": {
        "sha256": "383c08c546d7370630246f039c7ef4528fda101b607537845f9ad204c7df5bb7",
        "path": "blobs/383c08c546d7370630246f039c7ef4528fda101b607537845f9ad204c7df5bb7.json",
        "bytes": 5118,
        "media_type": "application/json"
      }
    },
    {
      "seq": 15,
      "event_id": "871213c6-6cf1-472e-93cd-89de549a7465",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.438Z",
      "monotonic_ms": 463.16190000000097,
      "payload_ref": {
        "sha256": "995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783",
        "path": "blobs/995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783.json",
        "bytes": 2529,
        "media_type": "application/json"
      }
    },
    {
      "seq": 51,
      "event_id": "777769d3-0f58-452e-b371-523a8f7238fb",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:42.668Z",
      "monotonic_ms": 1693.6026000000002,
      "payload_ref": {
        "sha256": "b37732410a2645ff794b6e6c1b8c4fd2fa3228ef365356fb56feffb061975683",
        "path": "blobs/b37732410a2645ff794b6e6c1b8c4fd2fa3228ef365356fb56feffb061975683.json",
        "bytes": 39352,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amountIn",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "10",
      "baseUnits": "10000000"
    },
    {
      "parameter": "minAmountOut",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9",
      "baseUnits": "9000000"
    }
  ],
  "decoded": {
    "functionName": "swap",
    "args": [
      "10000000",
      "9000000",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 10,
    "end_seq": 51,
    "start_time": "2026-11-16T06:22:41.238Z",
    "end_time": "2026-11-16T06:22:42.668Z",
    "duration_ms": 1430.4629999999997
  }
}
```

### transaction:0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f

```json
{
  "id": "transaction:0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
  "hash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
  "contractCallId": "2891c478-0689-48d7-b7f9-ab89e76538a2",
  "toolCallId": "scripted_00cfc833-6023-48fe-ac13-811beed92fad",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "data": "0x095ea7b3000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
    "value": "0",
    "nonce": 11,
    "gas": "46107",
    "maxFeePerGas": "1322115614",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1235008603"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "46107",
    "logs": [
      {
        "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
        "topics": [
          "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
        ],
        "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
        "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
        "blockNumber": "12",
        "blockTimestamp": "1794810161",
        "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      }
    ],
    "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000200000000840000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000020000000000000000000000000010000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000",
    "transactionHash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
    "transactionIndex": 0,
    "blockHash": "0x9697176949067bb4b62c8b5d1ff1715c7853fd24f0ac72b13887c02c42a04dad",
    "blockNumber": "12",
    "gasUsed": "46107",
    "effectiveGasPrice": "1235008603",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
    "contractAddress": null,
    "blockTimestamp": 1794810161
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 28,
      "event_id": "583dd461-890f-4ed5-9405-ffb4ce4b70cc",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:41.759Z",
      "monotonic_ms": 784.8075000000008,
      "payload_ref": {
        "sha256": "3a860ec94c293134ec60d149c5e22809638f459f1566bc779eab31e427e46d6f",
        "path": "blobs/3a860ec94c293134ec60d149c5e22809638f459f1566bc779eab31e427e46d6f.json",
        "bytes": 1162,
        "media_type": "application/json"
      }
    },
    {
      "seq": 30,
      "event_id": "26d4b6e0-1d1e-4c3d-b82f-5de5c61e922d",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:41.818Z",
      "monotonic_ms": 843.7075000000004,
      "payload_ref": {
        "sha256": "1f16fd4ac9f4ecbfeb200ea10f373b47b48d747a3aa7df78036f8cc4abd8f0b1",
        "path": "blobs/1f16fd4ac9f4ecbfeb200ea10f373b47b48d747a3aa7df78036f8cc4abd8f0b1.json",
        "bytes": 1162,
        "media_type": "application/json"
      }
    },
    {
      "seq": 31,
      "event_id": "a72b59e8-8b32-414b-815f-8f58d5d3fad1",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:41.946Z",
      "monotonic_ms": 970.9851000000017,
      "payload_ref": {
        "sha256": "4c3bde227bb3f21f43b01ddca6b2dcb382bd3a8aea07afeb9d7d1729ce234edf",
        "path": "blobs/4c3bde227bb3f21f43b01ddca6b2dcb382bd3a8aea07afeb9d7d1729ce234edf.json",
        "bytes": 3308,
        "media_type": "application/json"
      }
    },
    {
      "seq": 33,
      "event_id": "b474ec88-9529-4f09-ac70-6d24d9becc47",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.981Z",
      "monotonic_ms": 1005.9269000000004,
      "payload_ref": {
        "sha256": "3db66a20dc95b5ebdf5cad9d9cbbfea84c59b762ac09c767d9bd0dbe2e185568",
        "path": "blobs/3db66a20dc95b5ebdf5cad9d9cbbfea84c59b762ac09c767d9bd0dbe2e185568.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    },
    {
      "seq": 51,
      "event_id": "777769d3-0f58-452e-b371-523a8f7238fb",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:42.668Z",
      "monotonic_ms": 1693.6026000000002,
      "payload_ref": {
        "sha256": "b37732410a2645ff794b6e6c1b8c4fd2fa3228ef365356fb56feffb061975683",
        "path": "blobs/b37732410a2645ff794b6e6c1b8c4fd2fa3228ef365356fb56feffb061975683.json",
        "bytes": 39352,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9.940219",
      "baseUnits": "9940219"
    }
  ],
  "decoded": {
    "functionName": "approve",
    "args": [
      "0xA4c8CC45fEd2587d4B9120f296a5c7c379C400EC",
      "9940219"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 28,
    "end_seq": 51,
    "start_time": "2026-11-16T06:22:41.759Z",
    "end_time": "2026-11-16T06:22:42.668Z",
    "duration_ms": 908.7950999999994
  }
}
```

### transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75

```json
{
  "id": "transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "hash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "contractCallId": "f321af92-cd84-48dd-a553-1eee64de4eb7",
  "toolCallId": "scripted_440ff21c-4c84-4103-b1a4-af6ca0bb1132",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "data": "0x6e553f65000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 12,
    "gas": "107266",
    "maxFeePerGas": "1282010323",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1205722824"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "102466",
    "logs": [
      {
        "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
        "topics": [
          "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec"
        ],
        "data": "0x000000000000000000000000000000000000000000000000000000000097acfb",
        "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
        "blockNumber": "13",
        "blockTimestamp": "1794810162",
        "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      },
      {
        "address": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
        "topics": [
          "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
        ],
        "data": "0x000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000000000000000000000000000000000000097acfb",
        "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
        "blockNumber": "13",
        "blockTimestamp": "1794810162",
        "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
        "transactionIndex": 0,
        "logIndex": 1,
        "removed": false
      }
    ],
    "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000100000000080000840400000000000000008000000000000000000000000000000000000000000000000100000000000000000100000000800000004000000000010000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000010000000000000000000000000000000000000000402000000000000000000000000000000000008000000000000000000000000000000000000004000000000000000000000000000000000000000000000",
    "transactionHash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
    "transactionIndex": 0,
    "blockHash": "0x1ea31a274d7d4c4d2500afbd4fa97c8cfa1a05530fb1c612f9496c401a565841",
    "blockNumber": "13",
    "gasUsed": "102466",
    "effectiveGasPrice": "1205722824",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
    "contractAddress": null,
    "blockTimestamp": 1794810162
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 40,
      "event_id": "cb69236a-19fd-4380-9a6c-56a1b8329fd2",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:42.184Z",
      "monotonic_ms": 1208.9688000000006,
      "payload_ref": {
        "sha256": "a3251b326d258db19135339c80389a6dc6e2ca62f28194b1a4bf2f0ce01ca256",
        "path": "blobs/a3251b326d258db19135339c80389a6dc6e2ca62f28194b1a4bf2f0ce01ca256.json",
        "bytes": 1109,
        "media_type": "application/json"
      }
    },
    {
      "seq": 42,
      "event_id": "ea1237cb-a509-484b-8899-65a32d0d2948",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:42.198Z",
      "monotonic_ms": 1223.5202000000008,
      "payload_ref": {
        "sha256": "80ebf88173952162fd733e7fb77b45b8a31c3ee419a5668fd1f6ed24df73c4ad",
        "path": "blobs/80ebf88173952162fd733e7fb77b45b8a31c3ee419a5668fd1f6ed24df73c4ad.json",
        "bytes": 1109,
        "media_type": "application/json"
      }
    },
    {
      "seq": 43,
      "event_id": "deaadf2b-edea-47cb-9b92-d565607ed310",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:42.217Z",
      "monotonic_ms": 1242.0368000000017,
      "payload_ref": {
        "sha256": "8c9475faebbe5c8388dd077b4526c91f6109f3c93d5e1cf77db3e50ba00c9509",
        "path": "blobs/8c9475faebbe5c8388dd077b4526c91f6109f3c93d5e1cf77db3e50ba00c9509.json",
        "bytes": 4095,
        "media_type": "application/json"
      }
    },
    {
      "seq": 45,
      "event_id": "86857b5c-57a4-4940-a861-d0edc898d8ad",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:42.259Z",
      "monotonic_ms": 1284.123300000001,
      "payload_ref": {
        "sha256": "78004f16f296ba58c79657fe5555cf824d67b217312f681b3d0442e73bb675c7",
        "path": "blobs/78004f16f296ba58c79657fe5555cf824d67b217312f681b3d0442e73bb675c7.json",
        "bytes": 1173,
        "media_type": "application/json"
      }
    },
    {
      "seq": 51,
      "event_id": "777769d3-0f58-452e-b371-523a8f7238fb",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:42.668Z",
      "monotonic_ms": 1693.6026000000002,
      "payload_ref": {
        "sha256": "b37732410a2645ff794b6e6c1b8c4fd2fa3228ef365356fb56feffb061975683",
        "path": "blobs/b37732410a2645ff794b6e6c1b8c4fd2fa3228ef365356fb56feffb061975683.json",
        "bytes": 39352,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amount",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9.940219",
      "baseUnits": "9940219"
    }
  ],
  "decoded": {
    "functionName": "deposit",
    "args": [
      "9940219",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 40,
    "end_seq": 51,
    "start_time": "2026-11-16T06:22:42.184Z",
    "end_time": "2026-11-16T06:22:42.668Z",
    "duration_ms": 484.6337999999996
  }
}
```


## 内部EVM调用帧（callTracer父子树）

### evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0

```json
{
  "id": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0",
  "callId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0",
  "parentId": null,
  "transaction_id": "transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "input": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "output": "0x000000000000000000000000000000000000000000000000000000000097acfb",
  "value": "0x0",
  "gas": "0xa55d",
  "gasUsed": "0xe79d",
  "function": {
    "name": "swap",
    "signature": "swap(uint256,uint256,address)",
    "selector": "0x6d9a640a",
    "args": [
      "10000000",
      "9000000",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "amm"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "871213c6-6cf1-472e-93cd-89de549a7465",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.438Z",
      "monotonic_ms": 463.16190000000097,
      "payload_ref": {
        "sha256": "995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783",
        "path": "blobs/995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783.json",
        "bytes": 2529,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:41.438Z",
    "end_time": "2026-11-16T06:22:41.438Z",
    "duration_ms": 0
  }
}
```

### evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.0

```json
{
  "id": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.0",
  "callId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.0",
  "parentId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0",
  "transaction_id": "transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "trace_path": "0.0",
  "type": "STATICCALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0x70a08231000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
  "output": "0x0000000000000000000000000000000000000000000000000000000254a47a80",
  "gas": "0x9682",
  "gasUsed": "0x9ed",
  "function": {
    "name": "balanceOf",
    "signature": "balanceOf(address)",
    "selector": "0x70a08231",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "871213c6-6cf1-472e-93cd-89de549a7465",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.438Z",
      "monotonic_ms": 463.16190000000097,
      "payload_ref": {
        "sha256": "995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783",
        "path": "blobs/995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783.json",
        "bytes": 2529,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:41.438Z",
    "end_time": "2026-11-16T06:22:41.438Z",
    "duration_ms": 0
  }
}
```

### evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.1

```json
{
  "id": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.1",
  "callId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.1",
  "parentId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0",
  "transaction_id": "transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "trace_path": "0.1",
  "type": "STATICCALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
  "input": "0x70a08231000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
  "output": "0x000000000000000000000000000000000000000000000000000000025373e97b",
  "gas": "0x8119",
  "gasUsed": "0x9ed",
  "function": {
    "name": "balanceOf",
    "signature": "balanceOf(address)",
    "selector": "0x70a08231",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenB"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "871213c6-6cf1-472e-93cd-89de549a7465",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.438Z",
      "monotonic_ms": 463.16190000000097,
      "payload_ref": {
        "sha256": "995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783",
        "path": "blobs/995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783.json",
        "bytes": 2529,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:41.438Z",
    "end_time": "2026-11-16T06:22:41.438Z",
    "duration_ms": 0
  }
}
```

### evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.2

```json
{
  "id": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.2",
  "callId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.2",
  "parentId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0",
  "transaction_id": "transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "trace_path": "0.2",
  "type": "CALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0x23b872dd000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000000989680",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x74e2",
  "gasUsed": "0x40ac",
  "function": {
    "name": "transferFrom",
    "signature": "transferFrom(address,address,uint256)",
    "selector": "0x23b872dd",
    "args": [
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "0x933477D28d204bc2D05ee5B522a245536b27D69D",
      "10000000"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "871213c6-6cf1-472e-93cd-89de549a7465",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.438Z",
      "monotonic_ms": 463.16190000000097,
      "payload_ref": {
        "sha256": "995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783",
        "path": "blobs/995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783.json",
        "bytes": 2529,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:41.438Z",
    "end_time": "2026-11-16T06:22:41.438Z",
    "duration_ms": 0
  }
}
```

### evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.3

```json
{
  "id": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.3",
  "callId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0.3",
  "parentId": "evm:871213c6-6cf1-472e-93cd-89de549a7465%2F0",
  "transaction_id": "transaction:0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "hash": "0x9f3075e8c8a746fe07d6e267d80f859cc013d124f62eef29df229bd197ab3829",
  "trace_path": "0.3",
  "type": "CALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
  "input": "0xa9059cbb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9000000000000000000000000000000000000000000000000000000000097acfb",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x338d",
  "gasUsed": "0x2b0d",
  "function": {
    "name": "transfer",
    "signature": "transfer(address,uint256)",
    "selector": "0xa9059cbb",
    "args": [
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "9940219"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenB"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "871213c6-6cf1-472e-93cd-89de549a7465",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.438Z",
      "monotonic_ms": 463.16190000000097,
      "payload_ref": {
        "sha256": "995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783",
        "path": "blobs/995ef72023efc4a70ce840dedc7db7866c776bb203da5c978c8dc0c94bb1d783.json",
        "bytes": 2529,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:41.438Z",
    "end_time": "2026-11-16T06:22:41.438Z",
    "duration_ms": 0
  }
}
```

### evm:b474ec88-9529-4f09-ac70-6d24d9becc47%2F0

```json
{
  "id": "evm:b474ec88-9529-4f09-ac70-6d24d9becc47%2F0",
  "callId": "evm:b474ec88-9529-4f09-ac70-6d24d9becc47%2F0",
  "parentId": null,
  "transaction_id": "transaction:0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
  "hash": "0x7de7a4a4449c3a0cb226043bf40df087224945c76f9d270c8d25f3e971345e8f",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
  "input": "0x095ea7b3000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x5fcb",
  "gasUsed": "0xb41b",
  "function": {
    "name": "approve",
    "signature": "approve(address,uint256)",
    "selector": "0x095ea7b3",
    "args": [
      "0xA4c8CC45fEd2587d4B9120f296a5c7c379C400EC",
      "9940219"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenB"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 33,
      "event_id": "b474ec88-9529-4f09-ac70-6d24d9becc47",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:41.981Z",
      "monotonic_ms": 1005.9269000000004,
      "payload_ref": {
        "sha256": "3db66a20dc95b5ebdf5cad9d9cbbfea84c59b762ac09c767d9bd0dbe2e185568",
        "path": "blobs/3db66a20dc95b5ebdf5cad9d9cbbfea84c59b762ac09c767d9bd0dbe2e185568.json",
        "bytes": 598,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 33,
    "end_seq": 33,
    "start_time": "2026-11-16T06:22:41.981Z",
    "end_time": "2026-11-16T06:22:41.981Z",
    "duration_ms": 0
  }
}
```

### evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0

```json
{
  "id": "evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0",
  "callId": "evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0",
  "parentId": null,
  "transaction_id": "transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "hash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
  "input": "0x6e553f65000000000000000000000000000000000000000000000000000000000097acfb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "output": "0x000000000000000000000000000000000000000000000000000000000097acfb",
  "value": "0x0",
  "gas": "0x14ea6",
  "gasUsed": "0x19042",
  "function": {
    "name": "deposit",
    "signature": "deposit(uint256,address)",
    "selector": "0x6e553f65",
    "args": [
      "9940219",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "vault"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 45,
      "event_id": "86857b5c-57a4-4940-a861-d0edc898d8ad",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:42.259Z",
      "monotonic_ms": 1284.123300000001,
      "payload_ref": {
        "sha256": "78004f16f296ba58c79657fe5555cf824d67b217312f681b3d0442e73bb675c7",
        "path": "blobs/78004f16f296ba58c79657fe5555cf824d67b217312f681b3d0442e73bb675c7.json",
        "bytes": 1173,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 45,
    "end_seq": 45,
    "start_time": "2026-11-16T06:22:42.259Z",
    "end_time": "2026-11-16T06:22:42.259Z",
    "duration_ms": 0
  }
}
```

### evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0.0

```json
{
  "id": "evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0.0",
  "callId": "evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0.0",
  "parentId": "evm:86857b5c-57a4-4940-a861-d0edc898d8ad%2F0",
  "transaction_id": "transaction:0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "hash": "0x3a8eb1333c0a6593d6a2a958bd565b815f9b0fb6a846fc7d07d3954209391c75",
  "trace_path": "0.0",
  "type": "CALL",
  "from": "0xa4c8cc45fed2587d4b9120f296a5c7c379c400ec",
  "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
  "input": "0x23b872dd000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9000000000000000000000000a4c8cc45fed2587d4b9120f296a5c7c379c400ec000000000000000000000000000000000000000000000000000000000097acfb",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x13d5d",
  "gasUsed": "0x8b48",
  "function": {
    "name": "transferFrom",
    "signature": "transferFrom(address,address,uint256)",
    "selector": "0x23b872dd",
    "args": [
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "0xA4c8CC45fEd2587d4B9120f296a5c7c379C400EC",
      "9940219"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenB"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 45,
      "event_id": "86857b5c-57a4-4940-a861-d0edc898d8ad",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:42.259Z",
      "monotonic_ms": 1284.123300000001,
      "payload_ref": {
        "sha256": "78004f16f296ba58c79657fe5555cf824d67b217312f681b3d0442e73bb675c7",
        "path": "blobs/78004f16f296ba58c79657fe5555cf824d67b217312f681b3d0442e73bb675c7.json",
        "bytes": 1173,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 45,
    "end_seq": 45,
    "start_time": "2026-11-16T06:22:42.259Z",
    "end_time": "2026-11-16T06:22:42.259Z",
    "duration_ms": 0
  }
}
```


## 缺失与注意事项

未发现构建阶段结构警告。原始文件哈希核验由导出调用方负责；轨迹本身不判定任务成功。
