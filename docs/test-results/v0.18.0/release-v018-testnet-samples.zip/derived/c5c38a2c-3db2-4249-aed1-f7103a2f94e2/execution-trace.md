# Web3 Agent 执行轨迹

运行编号：c5c38a2c-3db2-4249-aed1-f7103a2f94e2

本文件由原始事件生成，用于查看执行关系。列表的记录顺序不代表因果关系；只有显式调用ID、交易哈希与callTracer父子关系形成连线。内部EVM调用是链执行证据，不是模型思维过程。

完整结构见同目录 execution-trace.json；模型原始完整响应body与工具原始记录通过 source_events.payload_ref 指向原始 blobs 文件。本文件不截断已展开实体。

## 任务与来源

```json
{
  "task": {
    "node_id": "task:c5c38a2c-3db2-4249-aed1-f7103a2f94e2",
    "id": "swap",
    "input": "使用实验amm将10 TokenA兑换为TokenB，最少接受9 TokenB，收款人为agent。调用swap传{\"amountIn\":\"10\",\"minAmountOut\":\"9\"}，不要乘代币精度。先检查formatted.allowances.ammA中的代币数量；若授权至少10则直接兑换，否则调用approve_token传{\"token\":\"A\",\"spender\":\"amm\",\"amount\":\"10\"}。不要将原始整数allowance或balance直接填入工具amount。",
    "mode": "scripted",
    "experiment_mode": "continuous",
    "amount_validation": "fixed_task",
    "data_origin": "scripted",
    "allowed_tools": [
      "get_balance",
      "get_state",
      "approve_token",
      "swap"
    ],
    "source_events": [
      {
        "seq": 4,
        "event_id": "a3b72ffe-796c-4633-8917-fcbc07b7a018",
        "type": "agent.start",
        "timestamp": "2026-11-16T06:22:40.017Z",
        "monotonic_ms": 65.28019999999924,
        "payload_ref": {
          "sha256": "ab446de2ca0c782a7b9fe6bc54da05cf5503501dc1cd487233a8d17ba2e547c8",
          "path": "blobs/ab446de2ca0c782a7b9fe6bc54da05cf5503501dc1cd487233a8d17ba2e547c8.json",
          "bytes": 4404,
          "media_type": "application/json"
        }
      }
    ],
    "task_parameters": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "parameter_source": "structured",
    "continuation_of": null
  },
  "provenance": {
    "kind": "derived",
    "source": "original_events",
    "builder_version": "1.2",
    "manifest_present": true,
    "recording_status": "complete",
    "sealed_at": "2026-11-16T06:22:40.792Z",
    "event_count": 22,
    "events_sha256": "435e0e398a302ca5a3657d673d24e61cb4a09ba76a3f8e2350730bf503fa38cd",
    "integrity": "raw_manifest_verified_before_derivation",
    "source_manifest_sha256": "f1bbb963a872535c6c7d14d2f9542d153f668e09a107c30cf6dd191ac3888ea5"
  },
  "summary": {
    "model_call_count": 0,
    "model_proposal_count": 0,
    "tool_call_count": 1,
    "tool_record_count": 1,
    "contract_call_count": 1,
    "explicit_contract_call_count": 1,
    "transaction_count": 1,
    "call_frame_count": 5,
    "edge_count": 9,
    "transaction_status_counts": {
      "success": 1
    },
    "model_used": false,
    "internal_trace_meaning": "EVM execution evidence; not model reasoning",
    "completeness": "recorded_events_only"
  }
}
```

## 步骤关系表

| 来源节点 | 关系 | 目标节点 | 原始事件序号 |
| --- | --- | --- | --- |
| task:c5c38a2c-3db2-4249-aed1-f7103a2f94e2 | scripted\_task\_step | tool:scripted\_b591ea05-6b94-4c00-b2fd-44677be0ef68 | 6 |
| tool:scripted\_b591ea05-6b94-4c00-b2fd-44677be0ef68 | invokes\_contract | contract:242ee36c-2bfc-4ab8-bb57-3f821e7e1c62 | 9, 16 |
| transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb | evm\_trace\_root | evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0 | 15 |
| evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0 | evm\_child\_call | evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.0 | 15 |
| evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0 | evm\_child\_call | evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.1 | 15 |
| evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0 | evm\_child\_call | evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.2 | 15 |
| evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0 | evm\_child\_call | evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.3 | 15 |
| contract:242ee36c-2bfc-4ab8-bb57-3f821e7e1c62 | submits\_transaction | transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb | 12, 13, 21 |
| tool:scripted\_b591ea05-6b94-4c00-b2fd-44677be0ef68 | submits\_transaction | transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb | 12, 13, 21 |

## 模型接口调用与提议（提议不等于工具执行）

没有记录到此类实体；不能据此补造调用。

## 工具执行（输入、原始结果、可见结果）

### tool:scripted\_b591ea05-6b94-4c00-b2fd-44677be0ef68

```json
{
  "id": "tool:scripted_b591ea05-6b94-4c00-b2fd-44677be0ef68",
  "source_events": [
    {
      "seq": 7,
      "event_id": "d37659fa-bf78-4dc2-9c5b-76c298af1b41",
      "type": "tool.call",
      "timestamp": "2026-11-16T06:22:40.023Z",
      "monotonic_ms": 71.07569999999942,
      "payload_ref": {
        "sha256": "74be9a2c993e2248a83fff2f96b9ebaf0d8c8e2502fc7e4fdebcd7969b321b88",
        "path": "blobs/74be9a2c993e2248a83fff2f96b9ebaf0d8c8e2502fc7e4fdebcd7969b321b88.json",
        "bytes": 164,
        "media_type": "application/json"
      }
    },
    {
      "seq": 8,
      "event_id": "b691ac62-47f6-46a3-ab5c-aa898aca5ebe",
      "type": "tool.started",
      "timestamp": "2026-11-16T06:22:40.025Z",
      "monotonic_ms": 72.58560000000034,
      "payload_ref": {
        "sha256": "8ddb3f7f2738835ca015f2242455d0ee77eab953c86cd090d17c5dc5f9c0c1fe",
        "path": "blobs/8ddb3f7f2738835ca015f2242455d0ee77eab953c86cd090d17c5dc5f9c0c1fe.json",
        "bytes": 83,
        "media_type": "application/json"
      }
    },
    {
      "seq": 17,
      "event_id": "aa236311-7662-4927-a483-88339c8930c3",
      "type": "tool.result",
      "timestamp": "2026-11-16T06:22:40.433Z",
      "monotonic_ms": 480.5113999999994,
      "payload_ref": {
        "sha256": "0fdeefebaa5f13009f7cf6ab944b7cb7274766d400a0209cf8d110fcc27d03dc",
        "path": "blobs/0fdeefebaa5f13009f7cf6ab944b7cb7274766d400a0209cf8d110fcc27d03dc.json",
        "bytes": 10923,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "completed",
  "toolCallId": "scripted_b591ea05-6b94-4c00-b2fd-44677be0ef68",
  "modelCallId": null,
  "name": "swap",
  "raw_arguments": "{\"amountIn\":\"10\",\"minAmountOut\":\"9\"}",
  "input": {
    "amountIn": "10",
    "minAmountOut": "9"
  },
  "execution_started": true,
  "raw_result": {
    "tool": "swap",
    "args": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "contractCallId": "242ee36c-2bfc-4ab8-bb57-3f821e7e1c62",
    "amountConversions": [
      {
        "parameter": "amountIn",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      },
      {
        "parameter": "minAmountOut",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9",
        "baseUnits": "9000000"
      }
    ],
    "operation": "task:swap",
    "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "txHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 9,
    "gas": "81193",
    "type": "eip1559",
    "maxFeePerGas": "1420212785",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1306539738",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "81193",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097fa85",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        },
        {
          "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
          "topics": [
            "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097fa85",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 2,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
      "transactionIndex": 0,
      "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
      "blockNumber": "10",
      "gasUsed": "81193",
      "effectiveGasPrice": "1306539738",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "contractAddress": null,
      "blockTimestamp": 1794810160
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "swap",
      "args": [
        "10000000",
        "9000000",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    },
    "amountOut": "9960069",
    "amountOutFormatted": "9.960069"
  },
  "visible_result": {
    "tool": "swap",
    "args": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "contractCallId": "242ee36c-2bfc-4ab8-bb57-3f821e7e1c62",
    "amountConversions": [
      {
        "parameter": "amountIn",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      },
      {
        "parameter": "minAmountOut",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9",
        "baseUnits": "9000000"
      }
    ],
    "operation": "task:swap",
    "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "txHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 9,
    "gas": "81193",
    "type": "eip1559",
    "maxFeePerGas": "1420212785",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1306539738",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "81193",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097fa85",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        },
        {
          "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
          "topics": [
            "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097fa85",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 2,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
      "transactionIndex": 0,
      "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
      "blockNumber": "10",
      "gasUsed": "81193",
      "effectiveGasPrice": "1306539738",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "contractAddress": null,
      "blockTimestamp": 1794810160
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "swap",
      "args": [
        "10000000",
        "9000000",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    },
    "amountOut": "9960069",
    "amountOutFormatted": "9.960069"
  },
  "overridden": false,
  "error": null,
  "start_end": {
    "start_seq": 7,
    "end_seq": 17,
    "start_time": "2026-11-16T06:22:40.023Z",
    "end_time": "2026-11-16T06:22:40.433Z",
    "duration_ms": 409.4357
  }
}
```


## 合约调用（读取或写交易）

### contract:242ee36c-2bfc-4ab8-bb57-3f821e7e1c62

```json
{
  "id": "contract:242ee36c-2bfc-4ab8-bb57-3f821e7e1c62",
  "source_events": [
    {
      "seq": 9,
      "event_id": "b4dc69e0-45ef-4344-9065-b7e066a355c9",
      "type": "contract.call",
      "timestamp": "2026-11-16T06:22:40.053Z",
      "monotonic_ms": 100.95689999999922,
      "payload_ref": {
        "sha256": "52fce7b18630d963d76a5a8b0ae8337696499933e53b9efcb49731bd7f4cc86c",
        "path": "blobs/52fce7b18630d963d76a5a8b0ae8337696499933e53b9efcb49731bd7f4cc86c.json",
        "bytes": 1164,
        "media_type": "application/json"
      }
    },
    {
      "seq": 16,
      "event_id": "918e305b-7312-4f5b-8656-5424f9bd56bb",
      "type": "contract.result",
      "timestamp": "2026-11-16T06:22:40.431Z",
      "monotonic_ms": 479.1178,
      "payload_ref": {
        "sha256": "08604f9769a56efdc518710e150454b3541c6d29a54efa808112712a57534bfc",
        "path": "blobs/08604f9769a56efdc518710e150454b3541c6d29a54efa808112712a57534bfc.json",
        "bytes": 5646,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "status": "success",
  "contractCallId": "242ee36c-2bfc-4ab8-bb57-3f821e7e1c62",
  "toolCallId": "scripted_b591ea05-6b94-4c00-b2fd-44677be0ef68",
  "kind": "transaction",
  "tool": "swap",
  "chainId": 84532,
  "legacy": false,
  "contract": {
    "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "label": "swap"
  },
  "function": {
    "name": "swap",
    "signature": "swap(uint256,uint256,address)",
    "selector": "0x6d9a640a",
    "args": [
      "10000000",
      "9000000",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "request": {
    "from": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0"
  },
  "amountConversions": [
    {
      "parameter": "amountIn",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "10",
      "baseUnits": "10000000"
    },
    {
      "parameter": "minAmountOut",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9",
      "baseUnits": "9000000"
    }
  ],
  "result": {
    "tool": "swap",
    "args": {
      "amountIn": "10",
      "minAmountOut": "9"
    },
    "contractCallId": "242ee36c-2bfc-4ab8-bb57-3f821e7e1c62",
    "amountConversions": [
      {
        "parameter": "amountIn",
        "token": "A",
        "unit": "token",
        "decimals": 6,
        "input": "10",
        "baseUnits": "10000000"
      },
      {
        "parameter": "minAmountOut",
        "token": "B",
        "unit": "token",
        "decimals": 6,
        "input": "9",
        "baseUnits": "9000000"
      }
    ],
    "operation": "task:swap",
    "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "txHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 9,
    "gas": "81193",
    "type": "eip1559",
    "maxFeePerGas": "1420212785",
    "maxPriorityFeePerGas": "1000000000",
    "status": "success",
    "signing": {
      "kind": "dedicated-test-account",
      "address": "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "secretMaterial": "excluded"
    },
    "gasPrice": "1306539738",
    "receipt": {
      "type": "eip1559",
      "status": "success",
      "cumulativeGasUsed": "81193",
      "logs": [
        {
          "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 0,
          "removed": false
        },
        {
          "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
          "topics": [
            "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
            "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x000000000000000000000000000000000000000000000000000000000097fa85",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 1,
          "removed": false
        },
        {
          "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
          "topics": [
            "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
            "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
          ],
          "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097fa85",
          "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
          "blockNumber": "10",
          "blockTimestamp": "1794810160",
          "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
          "transactionIndex": 0,
          "logIndex": 2,
          "removed": false
        }
      ],
      "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
      "transactionIndex": 0,
      "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
      "blockNumber": "10",
      "gasUsed": "81193",
      "effectiveGasPrice": "1306539738",
      "blobGasPrice": "1",
      "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
      "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
      "contractAddress": null,
      "blockTimestamp": 1794810160
    },
    "confirmations": 1,
    "requiredConfirmations": 1,
    "decoded": {
      "functionName": "swap",
      "args": [
        "10000000",
        "9000000",
        "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
      ]
    },
    "amountOut": "9960069",
    "amountOutFormatted": "9.960069"
  },
  "txHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "submitted": true,
  "start_end": {
    "start_seq": 9,
    "end_seq": 16,
    "start_time": "2026-11-16T06:22:40.053Z",
    "end_time": "2026-11-16T06:22:40.431Z",
    "duration_ms": 378.16090000000077
  }
}
```


## 交易与确认状态

### transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb

```json
{
  "id": "transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "contractCallId": "242ee36c-2bfc-4ab8-bb57-3f821e7e1c62",
  "toolCallId": "scripted_b591ea05-6b94-4c00-b2fd-44677be0ef68",
  "request": {
    "chainId": 84532,
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "data": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "value": "0",
    "nonce": 9,
    "gas": "81193",
    "maxFeePerGas": "1420212785",
    "maxPriorityFeePerGas": "1000000000",
    "type": "eip1559",
    "gasPrice": "1306539738"
  },
  "receipt": {
    "type": "eip1559",
    "status": "success",
    "cumulativeGasUsed": "81193",
    "logs": [
      {
        "address": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
        "topics": [
          "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d"
        ],
        "data": "0x0000000000000000000000000000000000000000000000000000000000989680",
        "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
        "blockNumber": "10",
        "blockTimestamp": "1794810160",
        "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
        "transactionIndex": 0,
        "logIndex": 0,
        "removed": false
      },
      {
        "address": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
        "topics": [
          "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
          "0x000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
        ],
        "data": "0x000000000000000000000000000000000000000000000000000000000097fa85",
        "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
        "blockNumber": "10",
        "blockTimestamp": "1794810160",
        "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
        "transactionIndex": 0,
        "logIndex": 1,
        "removed": false
      },
      {
        "address": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
        "topics": [
          "0xfa2dda1cc1b86e41239702756b13effbc1a092b5c57e3ad320fbe4f3b13fe235",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
          "0x000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9"
        ],
        "data": "0x0000000000000000000000000000000000000000000000000000000000989680000000000000000000000000000000000000000000000000000000000097fa85",
        "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
        "blockNumber": "10",
        "blockTimestamp": "1794810160",
        "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
        "transactionIndex": 0,
        "logIndex": 2,
        "removed": false
      }
    ],
    "logsBloom": "0x00000400000000000000000000000000000000000000000040000000000000000000000000008000000000000000000000000000000000000000100000000000100840000000000000000008400000000000000000000000000000000000000000000000000100000000000000000000000800000000000000000010000000000100000000000008000000000008000000000400000000000000000000800000000400000000000000000000000010000000000000000000000010000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
    "transactionHash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
    "transactionIndex": 0,
    "blockHash": "0xe9c13cc7dc657f7a8a306f98c0a26e06c416d286f8bc1295eac77f1d2915acbb",
    "blockNumber": "10",
    "gasUsed": "81193",
    "effectiveGasPrice": "1306539738",
    "blobGasPrice": "1",
    "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
    "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
    "contractAddress": null,
    "blockTimestamp": 1794810160
  },
  "status": "success",
  "error": null,
  "trace_available": true,
  "source_events": [
    {
      "seq": 10,
      "event_id": "e85e8230-66e6-4ba8-9d59-053d0d780b18",
      "type": "tx.prepared",
      "timestamp": "2026-11-16T06:22:40.219Z",
      "monotonic_ms": 266.5622999999996,
      "payload_ref": {
        "sha256": "80b5b079890d2967507e18c3f7ea41dc11490b4062702d6c9a2155b2d7444d78",
        "path": "blobs/80b5b079890d2967507e18c3f7ea41dc11490b4062702d6c9a2155b2d7444d78.json",
        "bytes": 1344,
        "media_type": "application/json"
      }
    },
    {
      "seq": 12,
      "event_id": "1cfaae98-b7d8-4164-900e-31c06fd0405f",
      "type": "tx.broadcast",
      "timestamp": "2026-11-16T06:22:40.278Z",
      "monotonic_ms": 325.6782999999996,
      "payload_ref": {
        "sha256": "dc64b70124176515e2f79677bb7b4d657755eaa32091adcb76745463142d9535",
        "path": "blobs/dc64b70124176515e2f79677bb7b4d657755eaa32091adcb76745463142d9535.json",
        "bytes": 1344,
        "media_type": "application/json"
      }
    },
    {
      "seq": 13,
      "event_id": "5488dc9c-d987-483e-83d0-457330a3132d",
      "type": "tx.receipt",
      "timestamp": "2026-11-16T06:22:40.401Z",
      "monotonic_ms": 449.2526999999991,
      "payload_ref": {
        "sha256": "8ed9f0e6580cf0fed45308ba59ab665ef1505c844c3cdbf73fc630f098c834df",
        "path": "blobs/8ed9f0e6580cf0fed45308ba59ab665ef1505c844c3cdbf73fc630f098c834df.json",
        "bytes": 5117,
        "media_type": "application/json"
      }
    },
    {
      "seq": 15,
      "event_id": "3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:40.428Z",
      "monotonic_ms": 475.9187000000002,
      "payload_ref": {
        "sha256": "cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399",
        "path": "blobs/cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399.json",
        "bytes": 2530,
        "media_type": "application/json"
      }
    },
    {
      "seq": 21,
      "event_id": "d7c8c5b0-7bc2-4021-a0f8-dcb8070570ab",
      "type": "check.evidence",
      "timestamp": "2026-11-16T06:22:40.774Z",
      "monotonic_ms": 822.2299999999996,
      "payload_ref": {
        "sha256": "3683b0ae49c32f394a0efc20f957ab7bf4dbe9d74084431994569daf218d3cd9",
        "path": "blobs/3683b0ae49c32f394a0efc20f957ab7bf4dbe9d74084431994569daf218d3cd9.json",
        "bytes": 17615,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "amountConversions": [
    {
      "parameter": "amountIn",
      "token": "A",
      "unit": "token",
      "decimals": 6,
      "input": "10",
      "baseUnits": "10000000"
    },
    {
      "parameter": "minAmountOut",
      "token": "B",
      "unit": "token",
      "decimals": 6,
      "input": "9",
      "baseUnits": "9000000"
    }
  ],
  "decoded": {
    "functionName": "swap",
    "args": [
      "10000000",
      "9000000",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ]
  },
  "observed_in_checker": true,
  "start_end": {
    "start_seq": 10,
    "end_seq": 21,
    "start_time": "2026-11-16T06:22:40.219Z",
    "end_time": "2026-11-16T06:22:40.774Z",
    "duration_ms": 555.6677
  }
}
```


## 内部EVM调用帧（callTracer父子树）

### evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0

```json
{
  "id": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0",
  "callId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0",
  "parentId": null,
  "transaction_id": "transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "trace_path": "0",
  "type": "CALL",
  "from": "0xf93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "to": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "input": "0x6d9a640a00000000000000000000000000000000000000000000000000000000009896800000000000000000000000000000000000000000000000000000000000895440000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9",
  "output": "0x000000000000000000000000000000000000000000000000000000000097fa85",
  "value": "0x0",
  "gas": "0xe829",
  "gasUsed": "0x13d29",
  "function": {
    "name": "swap",
    "signature": "swap(uint256,uint256,address)",
    "selector": "0x6d9a640a",
    "args": [
      "10000000",
      "9000000",
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "amm"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:40.428Z",
      "monotonic_ms": 475.9187000000002,
      "payload_ref": {
        "sha256": "cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399",
        "path": "blobs/cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399.json",
        "bytes": 2530,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:40.428Z",
    "end_time": "2026-11-16T06:22:40.428Z",
    "duration_ms": 0
  }
}
```

### evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.0

```json
{
  "id": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.0",
  "callId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.0",
  "parentId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0",
  "transaction_id": "transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "trace_path": "0.0",
  "type": "STATICCALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0x70a08231000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
  "output": "0x00000000000000000000000000000000000000000000000000000002540be400",
  "gas": "0xd843",
  "gasUsed": "0x9ed",
  "function": {
    "name": "balanceOf",
    "signature": "balanceOf(address)",
    "selector": "0x70a08231",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:40.428Z",
      "monotonic_ms": 475.9187000000002,
      "payload_ref": {
        "sha256": "cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399",
        "path": "blobs/cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399.json",
        "bytes": 2530,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:40.428Z",
    "end_time": "2026-11-16T06:22:40.428Z",
    "duration_ms": 0
  }
}
```

### evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.1

```json
{
  "id": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.1",
  "callId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.1",
  "parentId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0",
  "transaction_id": "transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "trace_path": "0.1",
  "type": "STATICCALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
  "input": "0x70a08231000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d",
  "output": "0x00000000000000000000000000000000000000000000000000000002540be400",
  "gas": "0xc2da",
  "gasUsed": "0x9ed",
  "function": {
    "name": "balanceOf",
    "signature": "balanceOf(address)",
    "selector": "0x70a08231",
    "args": [
      "0x933477D28d204bc2D05ee5B522a245536b27D69D"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenB"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:40.428Z",
      "monotonic_ms": 475.9187000000002,
      "payload_ref": {
        "sha256": "cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399",
        "path": "blobs/cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399.json",
        "bytes": 2530,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:40.428Z",
    "end_time": "2026-11-16T06:22:40.428Z",
    "duration_ms": 0
  }
}
```

### evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.2

```json
{
  "id": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.2",
  "callId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.2",
  "parentId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0",
  "transaction_id": "transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "trace_path": "0.2",
  "type": "CALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0x9fce589473a4482fce0e812e0d944d7c7e6f79f4",
  "input": "0x23b872dd000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9000000000000000000000000933477d28d204bc2d05ee5b522a245536b27d69d0000000000000000000000000000000000000000000000000000000000989680",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0xb6a2",
  "gasUsed": "0x40ac",
  "function": {
    "name": "transferFrom",
    "signature": "transferFrom(address,address,uint256)",
    "selector": "0x23b872dd",
    "args": [
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "0x933477D28d204bc2D05ee5B522a245536b27D69D",
      "10000000"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenA"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:40.428Z",
      "monotonic_ms": 475.9187000000002,
      "payload_ref": {
        "sha256": "cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399",
        "path": "blobs/cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399.json",
        "bytes": 2530,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:40.428Z",
    "end_time": "2026-11-16T06:22:40.428Z",
    "duration_ms": 0
  }
}
```

### evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.3

```json
{
  "id": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.3",
  "callId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0.3",
  "parentId": "evm:3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972%2F0",
  "transaction_id": "transaction:0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "hash": "0xe21238c481e1511a05db08d460c8c3fc4ae3f7415b692cc2f7b14c73151a11fb",
  "trace_path": "0.3",
  "type": "CALL",
  "from": "0x933477d28d204bc2d05ee5b522a245536b27d69d",
  "to": "0xc2f4cce8d46fbc490049d1dfd0f628c757e968f8",
  "input": "0xa9059cbb000000000000000000000000f93ae5ce9eba77f7c629a4cdbcb0c5afb76a1cb9000000000000000000000000000000000000000000000000000000000097fa85",
  "output": "0x0000000000000000000000000000000000000000000000000000000000000001",
  "value": "0x0",
  "gas": "0x754e",
  "gasUsed": "0x6dd9",
  "function": {
    "name": "transfer",
    "signature": "transfer(address,uint256)",
    "selector": "0xa9059cbb",
    "args": [
      "0xF93AE5ce9EBA77F7C629A4cdBcb0C5AfB76A1CB9",
      "9960069"
    ],
    "abi_source": "static_lab_abi_for_configured_address",
    "contract_label": "tokenB"
  },
  "status": "observed",
  "source_events": [
    {
      "seq": 15,
      "event_id": "3fb7e4f9-21db-4c39-a4f7-99d0bc2dd972",
      "type": "tx.trace",
      "timestamp": "2026-11-16T06:22:40.428Z",
      "monotonic_ms": 475.9187000000002,
      "payload_ref": {
        "sha256": "cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399",
        "path": "blobs/cb12dd9a391afee49c9bd3e38514348d342eecd7c08d79a2ae72fc3505e2b399.json",
        "bytes": 2530,
        "media_type": "application/json"
      }
    }
  ],
  "missing": [],
  "start_end": {
    "start_seq": 15,
    "end_seq": 15,
    "start_time": "2026-11-16T06:22:40.428Z",
    "end_time": "2026-11-16T06:22:40.428Z",
    "duration_ms": 0
  }
}
```


## 缺失与注意事项

未发现构建阶段结构警告。原始文件哈希核验由导出调用方负责；轨迹本身不判定任务成功。
